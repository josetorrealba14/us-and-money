export type Language = 'en' | 'es';

export interface Translations {
  // Landing page
  landing: {
    hero: {
      title: string;
      subtitle: string;
      cta: string;
    };
    features: {
      title: string;
      items: {
        track: { title: string; description: string };
        split: { title: string; description: string };
        settle: { title: string; description: string };
      };
    };
    modes: {
      title: string;
      solo: { title: string; description: string };
      couple: { title: string; description: string };
      roommates: { title: string; description: string };
    };
    cta: {
      title: string;
      button: string;
    };
  };
  
  // Common
  common: {
    cancel: string;
    save: string;
    delete: string;
    edit: string;
    add: string;
    continue: string;
    skip: string;
    back: string;
    close: string;
    getStarted: string;
    settings: string;
    you: string;
    confirm: string;
  };
  
  // Modes
  modes: {
    solo: string;
    couple: string;
    roommates: string;
  };
  
  // Onboarding
  onboarding: {
    stepLabel: string;
    ofLabel: string;
    step1: {
      title: string;
      description: string;
      soloDescription: string;
      coupleDescription: string;
      roommatesDescription: string;
    };
    step2: {
      title: string;
      description: string;
      exampleTitle: string;
      examplePaidBy: string;
      exampleSplitEqually: string;
    };
    step3: {
      title: string;
      descriptionSolo: string;
      descriptionShared: string;
      exampleOwes: string;
      exampleMonthlyExpenses: string;
    };
    next: string;
    back: string;
    finish: string;
    skip: string;
  };
  
  // Mode Setup
  modeSetup: {
    solo: {
      title: string;
      description: string;
      message: string;
      helperText: string;
    };
    couple: {
      title: string;
      description: string;
      questionPartnerName: string;
      partnerNamePlaceholder: string;
      helperText: string;
    };
    roommates: {
      title: string;
      description: string;
      questionCount: string;
      totalPeople: string;
      nameRoommates: string;
      roommatePlaceholder: string;
      helperText: string;
    };
    completeSetup: string;
  };
  
  // Budget
  budget: {
    personalBudget: string;
    sharedBudgetCouple: string;
    sharedBudgetRoommates: string;
    setBudget: string;
    chooseAmount: string;
    customAmount: string;
    custom: string;
    enterCustomAmount: string;
    perMonth: string;
    groupTotal: string;
    remaining: string;
    overBudgetBy: string;
    youreDoingGreat: string;
    reviewSpending: string;
    helperPersonal: string;
    helperSharedAll: string;
    helperSharedOnly: string;
    setPersonalDescription: string;
    setCoupleDescription: string;
    setRoommatesDescription: string;
    includePersonalExpenses: string;
    includePersonalOn: string;
    includePersonalOff: string;
    settlementsNote: string;
    budgetSettings: string;
  };
  
  // Status
  status: {
    onTrack: string;
    watchSpending: string;
    overBudget: string;
  };
  
  // Dashboard
  dashboard: {
    title: string;
    totalSpent: string;
    remainingBudget: string;
    projectedSavings: string;
    dailyAverage: string;
    projectedTotal: string;
    expenses: string;
    noExpenses: string;
    addFirstExpense: string;
    budgetVsSpending: string;
    expenseSplit: string;
    spendingByCategory: string;
    settlements: string;
    noSettlements: string;
    allSettled: string;
    week: string;
    budget: string;
    actual: string;
    weeklySpend: string;
    ofBudget: string;
    noExpensesInCategory: string;
    showAllExpenses: string;
    budgetedThisMonth: string;
    yourExpenses: string;
    recentTransactions: string;
    trackPersonalFinances: string;
    manageSharedExpensesPartner: string;
    manageSharedExpensesRoommates: string;
    welcomeToUsAndMoney: string;
    letsStartTracking: string;
    topCategory: string;
    noSpendingYet: string;
  };
  
  // Expenses
  expenses: {
    addExpense: string;
    editExpense: string;
    amount: string;
    description: string;
    date: string;
    paidBy: string;
    category: string;
    selectCategory: string;
    shared: string;
    personal: string;
    splitType: string;
    equalSplit: string;
    customSplit: string;
    deleteExpense: string;
    confirmDelete: string;
    filterByCategory: string;
    all: string;
    distributeEqually: string;
    percentageMustTotal100: string;
  };
  
  // Categories
  categories: {
    food: string;
    rent: string;
    transport: string;
    fun: string;
    utilities: string;
    other: string;
  };
  
  // Members
  members: {
    members: string;
    addMember: string;
    removeMember: string;
    memberName: string;
    you: string;
    confirmRemove: string;
  };
  
  // Settlements
  settlements: {
    title: string;
    emptyState: string;
    emptyStateDescription: string;
    whoOwesWhom: string;
    pays: string;
    owes: string;
    youOwe: string;
    owesYou: string;
    to: string;
  };
  
  // Month
  month: {
    currentMonth: string;
    previousMonth: string;
    nextMonth: string;
  };
  
  // Toast messages
  toast: {
    expenseAdded: string;
    expenseDeleted: string;
    budgetSet: string;
    budgetRemoved: string;
    memberAdded: string;
    memberRemoved: string;
    memberUpdated: string;
    setupComplete: string;
    personalIncluded: string;
    personalExcluded: string;
    languageChanged: string;
  };
  
  // Settings
  settings: {
    title: string;
    language: string;
    selectLanguage: string;
    resetData: string;
    resetDataConfirm: string;
    resetDataWarning: string;
    resetDataSuccess: string;
  };
}

export const translations: Record<Language, Translations> = {
  en: {
    landing: {
      hero: {
        title: 'Us&Money — manage shared money without the fights',
        subtitle: 'Track expenses, split costs fairly, and keep everyone happy. Built for couples and roommates who want to stay organized without the drama.',
        cta: 'Start Tracking Free',
      },
      features: {
        title: 'Everything you need to manage money together',
        items: {
          track: {
            title: 'Track Spending',
            description: 'Monitor expenses against your monthly budget with real-time insights',
          },
          split: {
            title: 'Split Fairly',
            description: 'Divide costs equally or customize splits based on your situation',
          },
          settle: {
            title: 'Settle Up Easy',
            description: 'See who owes whom with automatic balance calculations',
          },
        },
      },
      modes: {
        title: 'Three modes for every situation',
        solo: {
          title: 'Solo',
          description: 'Track your personal budget and expenses',
        },
        couple: {
          title: 'Couple',
          description: 'Manage shared expenses with your partner',
        },
        roommates: {
          title: 'Roommates',
          description: 'Split household costs with multiple people',
        },
      },
      cta: {
        title: 'Ready to take control?',
        button: 'Get Started Now',
      },
    },
    common: {
      cancel: 'Cancel',
      save: 'Save',
      delete: 'Delete',
      edit: 'Edit',
      add: 'Add',
      continue: 'Continue',
      skip: 'Skip',
      back: 'Back',
      close: 'Close',
      getStarted: 'Get Started',
      settings: 'Settings',
      you: 'You',
      confirm: 'Confirm',
    },
    modes: {
      solo: 'Solo',
      couple: 'Couple',
      roommates: 'Roommates',
    },
    onboarding: {
      stepLabel: 'Step',
      ofLabel: 'of',
      step1: {
        title: 'Welcome to Us&Money!',
        description: "Let's get started by choosing how you'll use the app.",
        soloDescription: 'Track your personal expenses',
        coupleDescription: 'Manage expenses with your partner',
        roommatesDescription: 'Split costs with your housemates',
      },
      step2: {
        title: 'Track Every Expense',
        description: 'Add expenses as they happen. Tag who paid, split costs fairly, and see your spending in real-time.',
        exampleTitle: 'Groceries',
        examplePaidBy: 'Paid by',
        exampleSplitEqually: 'Split equally',
      },
      step3: {
        title: 'See Who Owes What',
        descriptionSolo: 'View your spending breakdown, track your budget, and understand your finances at a glance.',
        descriptionShared: 'Automatically calculate who owes whom. No awkward conversations, just clear numbers.',
        exampleOwes: 'owes',
        exampleMonthlyExpenses: 'Monthly expenses',
      },
      next: 'Next',
      back: 'Back',
      finish: "Let's Go!",
      skip: 'Skip tutorial',
    },
    modeSetup: {
      solo: {
        title: 'Personal Setup',
        description: 'Track your personal finances',
        message: "You're all set! Your personal budget tracker is ready to use.",
        helperText: 'Your personal budget helps you track spending and stay on target',
      },
      couple: {
        title: 'Couple Setup',
        description: 'Manage expenses with your partner',
        questionPartnerName: "What is your partner's name?",
        partnerNamePlaceholder: "Partner's name",
        helperText: "You'll be tracking a shared budget for both of you. Perfect for managing joint expenses!",
      },
      roommates: {
        title: 'Roommates Setup',
        description: 'Split costs with your housemates',
        questionCount: 'How many roommates do you have?',
        totalPeople: 'Total people including you',
        nameRoommates: 'Name your roommates',
        roommatePlaceholder: 'Roommate',
        helperText: "You'll be tracking a shared budget for the household. Great for managing group expenses!",
      },
      completeSetup: 'Complete Setup',
    },
    budget: {
      personalBudget: 'Your personal budget',
      sharedBudgetCouple: 'Shared budget for both of you',
      sharedBudgetRoommates: 'Shared budget for the household',
      setBudget: 'Set Budget',
      chooseAmount: 'Choose a budget amount:',
      customAmount: 'Enter custom amount:',
      custom: 'Custom',
      enterCustomAmount: 'Enter amount',
      perMonth: '/ month',
      groupTotal: 'Group total',
      remaining: 'remaining',
      overBudgetBy: 'Over budget by',
      youreDoingGreat: "You're doing great! Keep it up",
      reviewSpending: 'Consider reviewing your spending to get back on track',
      helperPersonal: 'Tracks all your personal expenses',
      helperSharedAll: 'Tracks shared + personal expenses for the group',
      helperSharedOnly: 'Tracks only shared expenses (personal expenses excluded)',
      setPersonalDescription: 'Set a monthly budget to track your personal spending',
      setCoupleDescription: 'Set a shared budget for both of you this month',
      setRoommatesDescription: 'Set a shared budget for the household this month',
      includePersonalExpenses: 'Include personal expenses',
      includePersonalOn: 'Counts shared + personal expenses toward budget',
      includePersonalOff: 'Counts only shared expenses toward budget',
      settlementsNote: 'Note: Settlements always use only shared expenses',
      budgetSettings: 'Budget Settings',
    },
    status: {
      onTrack: 'On track',
      watchSpending: 'Watch spending',
      overBudget: 'Over budget',
    },
    dashboard: {
      title: 'Dashboard',
      totalSpent: 'Total Spent',
      remainingBudget: 'Remaining Budget',
      projectedSavings: 'Projected Savings',
      dailyAverage: 'Daily Average',
      projectedTotal: 'Projected Total',
      expenses: 'Expenses',
      noExpenses: 'No expenses yet',
      addFirstExpense: 'Add your first expense to get started',
      budgetVsSpending: 'Budget vs Spending',
      expenseSplit: 'Expense Split',
      spendingByCategory: 'Spending by Category',
      settlements: 'Settlements',
      noSettlements: 'No settlements needed',
      allSettled: "Everyone's balance is settled!",
      week: 'Week',
      budget: 'Budget',
      actual: 'Actual',
      weeklySpend: 'Weekly Spend',
      ofBudget: 'of budget',
      noExpensesInCategory: 'No expenses in this category',
      showAllExpenses: 'Show all expenses',
      budgetedThisMonth: 'budgeted this month',
      yourExpenses: 'Your Expenses',
      recentTransactions: 'Recent Transactions',
      trackPersonalFinances: 'Track Personal Finances',
      manageSharedExpensesPartner: 'Manage Shared Expenses with Partner',
      manageSharedExpensesRoommates: 'Manage Shared Expenses with Roommates',
      welcomeToUsAndMoney: 'Welcome to Us&Money',
      letsStartTracking: "Let's Start Tracking",
      topCategory: 'Top Category',
      noSpendingYet: 'No spending yet',
    },
    expenses: {
      addExpense: 'Add Expense',
      editExpense: 'Edit Expense',
      amount: 'Amount',
      description: 'Description',
      date: 'Date',
      paidBy: 'Paid by',
      category: 'Category',
      selectCategory: 'Select category',
      shared: 'Shared',
      personal: 'Personal',
      splitType: 'Split type',
      equalSplit: 'Equal split',
      customSplit: 'Custom split',
      deleteExpense: 'Delete expense?',
      confirmDelete: 'This action cannot be undone',
      filterByCategory: 'Filter by category',
      all: 'All',
      distributeEqually: 'Distribute equally',
      percentageMustTotal100: 'Percentage splits must add up to 100%',
    },
    categories: {
      food: 'Food',
      rent: 'Rent',
      transport: 'Transport',
      fun: 'Fun',
      utilities: 'Utilities',
      other: 'Other',
    },
    members: {
      members: 'Members',
      addMember: 'Add Member',
      removeMember: 'Remove member?',
      memberName: 'Member name',
      you: 'You',
      confirmRemove: 'This will remove this member from all future expenses',
    },
    settlements: {
      title: 'Settlements',
      emptyState: 'No settlements needed',
      emptyStateDescription: "Everyone's balance is settled!",
      whoOwesWhom: 'Who Owes Whom',
      pays: 'pays',
      owes: 'owes',
      youOwe: 'You owe',
      owesYou: 'owes you',
      to: 'to',
    },
    month: {
      currentMonth: 'Current Month',
      previousMonth: 'Previous Month',
      nextMonth: 'Next Month',
    },
    toast: {
      expenseAdded: 'Expense added',
      expenseDeleted: 'Expense deleted',
      budgetSet: 'Budget set successfully',
      budgetRemoved: 'Budget removed',
      memberAdded: 'Member added',
      memberRemoved: 'Member removed',
      memberUpdated: 'Member updated',
      setupComplete: 'Setup complete!',
      personalIncluded: 'Personal expenses included in budget',
      personalExcluded: 'Personal expenses excluded from budget',
      languageChanged: 'Language changed',
    },
    settings: {
      title: 'Settings',
      language: 'Language',
      selectLanguage: 'Select language',
      resetData: 'Reset Data',
      resetDataConfirm: 'Are you sure you want to reset all your data? This action cannot be undone.',
      resetDataWarning: 'Warning: This will delete all your expenses, budgets, and settings.',
      resetDataSuccess: 'Data reset successfully. All your data has been cleared.',
    },
  },
  es: {
    landing: {
      hero: {
        title: 'Us&Money — gestiona el dinero en pareja sin peleas',
        subtitle: 'Rastrea gastos, divide costos justamente y mantén a todos felices. Creado para parejas y compañeros que quieren organizarse sin dramas.',
        cta: 'Empezar Gratis',
      },
      features: {
        title: 'Todo lo que necesitas para gestionar dinero juntos',
        items: {
          track: {
            title: 'Seguimiento de Gastos',
            description: 'Monitorea gastos contra tu presupuesto mensual con información en tiempo real',
          },
          split: {
            title: 'División Justa',
            description: 'Divide costos equitativamente o personaliza según tu situación',
          },
          settle: {
            title: 'Liquida Fácilmente',
            description: 'Ve quién debe a quién con cálculos automáticos de saldo',
          },
        },
      },
      modes: {
        title: 'Tres modos para cada situación',
        solo: {
          title: 'Individual',
          description: 'Rastrea tu presupuesto y gastos personales',
        },
        couple: {
          title: 'Pareja',
          description: 'Gestiona gastos compartidos con tu pareja',
        },
        roommates: {
          title: 'Compañeros',
          description: 'Divide costos del hogar con varias personas',
        },
      },
      cta: {
        title: '¿Listo para tomar control?',
        button: 'Comenzar Ahora',
      },
    },
    common: {
      cancel: 'Cancelar',
      save: 'Guardar',
      delete: 'Eliminar',
      edit: 'Editar',
      add: 'Agregar',
      continue: 'Continuar',
      skip: 'Omitir',
      back: 'Atrás',
      close: 'Cerrar',
      getStarted: 'Comenzar',
      settings: 'Configuración',
      you: 'Tú',
      confirm: 'Confirmar',
    },
    modes: {
      solo: 'Solo',
      couple: 'Pareja',
      roommates: 'Roommates',
    },
    onboarding: {
      stepLabel: 'Paso',
      ofLabel: 'de',
      step1: {
        title: 'Bienvenido a Us&Money!',
        description: "Vamos a empezar eligiendo cómo usar la app.",
        soloDescription: 'Rastrea tus gastos personales',
        coupleDescription: 'Gestiona gastos con tu pareja',
        roommatesDescription: 'Divide costos con tus compañeros de casa',
      },
      step2: {
        title: 'Rastrea Cada Gasto',
        description: 'Agrega gastos a medida que ocurren. Etiqueta quién pagó, divide costos justamente y ve tus gastos en tiempo real.',
        exampleTitle: 'Compras',
        examplePaidBy: 'Pagado por',
        exampleSplitEqually: 'Dividir igualmente',
      },
      step3: {
        title: 'Ver Quién Debe a Quién',
        descriptionSolo: 'Ver el desglose de tus gastos, rastrea tu presupuesto y entiende tus finanzas a simple vista.',
        descriptionShared: 'Calcula automáticamente quién debe a quién. Sin conversaciones incómodas, solo números claros.',
        exampleOwes: 'debe',
        exampleMonthlyExpenses: 'Gastos mensuales',
      },
      next: 'Siguiente',
      back: 'Atrás',
      finish: "¡Vamos!",
      skip: 'Omitir tutorial',
    },
    modeSetup: {
      solo: {
        title: 'Configuración Personal',
        description: 'Rastrea tus finanzas personales',
        message: '¡Todo listo! Tu rastreador de presupuesto personal está listo para usar.',
        helperText: 'Tu presupuesto personal te ayuda a rastrear gastos y mantenerte en objetivo',
      },
      couple: {
        title: 'Configuración de Pareja',
        description: 'Gestiona gastos con tu pareja',
        questionPartnerName: '¿Cómo se llama tu pareja?',
        partnerNamePlaceholder: 'Nombre de la pareja',
        helperText: 'Vas a rastrear un presupuesto compartido para ambos. ¡Perfecto para gestionar gastos conjuntos!',
      },
      roommates: {
        title: 'Configuración de Compañeros',
        description: 'Divide costos con tus compañeros de casa',
        questionCount: '¿Cuántos compañeros de casa tienes?',
        totalPeople: 'Total de personas incluyéndote',
        nameRoommates: 'Nombra a tus compañeros',
        roommatePlaceholder: 'Compañero',
        helperText: 'Vas a rastrear un presupuesto compartido para el hogar. ¡Genial para gestionar gastos grupales!',
      },
      completeSetup: 'Completar Configuración',
    },
    budget: {
      personalBudget: 'Tu presupuesto personal',
      sharedBudgetCouple: 'Presupuesto compartido para ambos',
      sharedBudgetRoommates: 'Presupuesto compartido del hogar',
      setBudget: 'Establecer Presupuesto',
      chooseAmount: 'Elige un monto de presupuesto:',
      customAmount: 'Ingresa monto personalizado:',
      custom: 'Personalizado',
      enterCustomAmount: 'Ingresar monto',
      perMonth: '/ mes',
      groupTotal: 'Total del grupo',
      remaining: 'restante',
      overBudgetBy: 'Excedido por',
      youreDoingGreat: '¡Lo estás haciendo genial! Sigue así',
      reviewSpending: 'Considera revisar tus gastos para volver al objetivo',
      helperPersonal: 'Rastrea todos tus gastos personales',
      helperSharedAll: 'Rastrea gastos compartidos + personales del grupo',
      helperSharedOnly: 'Rastrea solo gastos compartidos (gastos personales excluidos)',
      setPersonalDescription: 'Establece un presupuesto mensual para rastrear tus gastos personales',
      setCoupleDescription: 'Establece un presupuesto compartido para ambos este mes',
      setRoommatesDescription: 'Establece un presupuesto compartido para el hogar este mes',
      includePersonalExpenses: 'Incluir gastos personales',
      includePersonalOn: 'Cuenta gastos compartidos + personales en el presupuesto',
      includePersonalOff: 'Cuenta solo gastos compartidos en el presupuesto',
      settlementsNote: 'Nota: Las liquidaciones siempre usan solo gastos compartidos',
      budgetSettings: 'Configuración de Presupuesto',
    },
    status: {
      onTrack: 'En objetivo',
      watchSpending: 'Controla gastos',
      overBudget: 'Presupuesto excedido',
    },
    dashboard: {
      title: 'Panel',
      totalSpent: 'Total Gastado',
      remainingBudget: 'Presupuesto Restante',
      projectedSavings: 'Ahorro Proyectado',
      dailyAverage: 'Promedio Diario',
      projectedTotal: 'Total Proyectado',
      expenses: 'Gastos',
      noExpenses: 'Aún no hay gastos',
      addFirstExpense: 'Agrega tu primer gasto para comenzar',
      budgetVsSpending: 'Presupuesto vs Gastos',
      expenseSplit: 'División de Gastos',
      spendingByCategory: 'Gasto por Categoría',
      settlements: 'Cuentas Pendientes',
      noSettlements: 'No hay cuentas pendientes',
      allSettled: '¡Todo al día!',
      week: 'Semana',
      budget: 'Presupuesto',
      actual: 'Real',
      weeklySpend: 'Gasto Semanal',
      ofBudget: 'del presupuesto',
      noExpensesInCategory: 'No hay gastos en esta categoría',
      showAllExpenses: 'Mostrar todos los gastos',
      budgetedThisMonth: 'presupuestado este mes',
      yourExpenses: 'Tus Gastos',
      recentTransactions: 'Transacciones Recientes',
      trackPersonalFinances: 'Rastrear Finanzas Personales',
      manageSharedExpensesPartner: 'Gestionar Gastos Compartidos con Pareja',
      manageSharedExpensesRoommates: 'Gestionar Gastos Compartidos con Roommates',
      welcomeToUsAndMoney: 'Bienvenido a Us&Money',
      letsStartTracking: 'Comenzar a Rastrear',
      topCategory: 'Categoría Principal',
      noSpendingYet: 'No hay gastos aún',
    },
    expenses: {
      addExpense: 'Agregar Gasto',
      editExpense: 'Editar Gasto',
      amount: 'Monto',
      description: 'Descripción',
      date: 'Fecha',
      paidBy: 'Pagado por',
      category: 'Categoría',
      selectCategory: 'Seleccionar categoría',
      shared: 'Compartido',
      personal: 'Personal',
      splitType: 'Tipo de división',
      equalSplit: 'División igual',
      customSplit: 'División personalizada',
      deleteExpense: '¿Eliminar gasto?',
      confirmDelete: 'Esta acción no se puede deshacer',
      filterByCategory: 'Filtrar por categoría',
      all: 'Todos',
      distributeEqually: 'Distribuir Igualmente',
      percentageMustTotal100: 'Los porcentajes deben sumar 100%',
    },
    categories: {
      food: 'Comida',
      rent: 'Renta',
      transport: 'Transporte',
      fun: 'Diversión',
      utilities: 'Servicios',
      other: 'Otro',
    },
    members: {
      members: 'Miembros',
      addMember: 'Agregar Miembro',
      removeMember: '¿Eliminar miembro?',
      memberName: 'Nombre del miembro',
      you: 'Tú',
      confirmRemove: 'Esto eliminará este miembro de todos los gastos futuros',
    },
    settlements: {
      title: 'Cuentas Pendientes',
      emptyState: '¡Todo al día!',
      emptyStateDescription: 'No hay cuentas pendientes',
      whoOwesWhom: 'Quién Debe a Quién',
      pays: 'paga',
      owes: 'debe',
      youOwe: 'Debes',
      owesYou: 'te debe',
      to: 'a',
    },
    month: {
      currentMonth: 'Mes Actual',
      previousMonth: 'Mes Anterior',
      nextMonth: 'Mes Siguiente',
    },
    toast: {
      expenseAdded: 'Gasto agregado',
      expenseDeleted: 'Gasto eliminado',
      budgetSet: 'Presupuesto establecido exitosamente',
      budgetRemoved: 'Presupuesto eliminado',
      memberAdded: 'Miembro agregado',
      memberRemoved: 'Miembro eliminado',
      memberUpdated: 'Miembro actualizado',
      setupComplete: '¡Configuración completa!',
      personalIncluded: 'Gastos personales incluidos en el presupuesto',
      personalExcluded: 'Gastos personales excluidos del presupuesto',
      languageChanged: 'Idioma cambiado',
    },
    settings: {
      title: 'Configuración',
      language: 'Idioma',
      selectLanguage: 'Seleccionar idioma',
      resetData: 'Restablecer Datos',
      resetDataConfirm: '¿Estás seguro de que quieres restablecer todos tus datos? Esta acción no se puede deshacer.',
      resetDataWarning: 'Advertencia: Esto eliminará todos tus gastos, presupuestos y configuraciones.',
      resetDataSuccess: 'Datos restablecidos exitosamente. Todos tus datos han sido eliminados.',
    },
  },
};