import { createBrowserRouter } from 'react-router';
import { Landing } from './pages/landing';
import { Dashboard } from './pages/dashboard';
import { Settings } from './pages/settings';
import { RootLayout } from './components/root-layout';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: RootLayout,
    children: [
      {
        index: true,
        Component: Landing,
      },
      {
        path: 'dashboard',
        Component: Dashboard,
      },
      {
        path: 'settings',
        Component: Settings,
      },
    ],
  },
]);