'use client';

import { RouterProvider } from 'react-router';
import { router } from './routes.tsx';
import { Toaster } from 'sonner';
import { LanguageProvider } from './hooks/useLanguage';

export default function App() {
  return (
    <LanguageProvider>
      <RouterProvider router={router} />
      <Toaster position="top-center" />
    </LanguageProvider>
  );
}