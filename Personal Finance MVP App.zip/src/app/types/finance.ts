export type Mode = 'solo' | 'couple' | 'roommates';

export type SplitType = 'equal' | 'percent';

export type Category = 'Food' | 'Rent' | 'Transport' | 'Fun' | 'Utilities' | 'Other';

export interface Member {
  id: string;
  name: string;
}

export interface Expense {
  id: string;
  amount: number;
  description: string;
  date: string;
  paidBy: string; // member id
  shared: boolean;
  splitType: SplitType;
  category?: Category;
  splits?: { [memberId: string]: number }; // For percent split
}

export interface Balance {
  memberId: string;
  balance: number; // positive = owed, negative = owes
}

export interface Settlement {
  from: string; // member id
  to: string; // member id
  amount: number;
}

export interface MonthlyData {
  expenses: Expense[];
  budget?: number;
}

export interface ModeWorkspace {
  members: Member[];
  months: { [key: string]: MonthlyData }; // key format: "2026-02"
  setupComplete?: boolean;
  includePersonalInBudget?: boolean; // For couple/roommates: whether to include personal expenses in budget tracking
}

export interface AppState {
  currentMode: Mode;
  workspaces: {
    solo: ModeWorkspace;
    couple: ModeWorkspace;
    roommates: ModeWorkspace;
  };
  hasSeenOnboarding: boolean;
}

export const CATEGORIES: Category[] = ['Food', 'Rent', 'Transport', 'Fun', 'Utilities', 'Other'];