'use client';

import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router';
import { Wallet, DollarSign, PiggyBank, ArrowLeft, Menu, Plus, Trash2, Filter, TrendingDown, TrendingUp, Settings2 } from 'lucide-react';
import { toast } from 'sonner';
import { ModeSelector } from '../components/mode-selector';
import { StatCard } from '../components/stat-card';
import { IncomeChart } from '../components/income-chart';
import { SplitChart } from '../components/split-chart';
import { CategoryChart } from '../components/category-chart';
import { AddExpenseModal } from '../components/add-expense-modal';
import { SettlementsCard } from '../components/settlements-card';
import { MemberManager } from '../components/member-manager';
import { BudgetCard } from '../components/budget-card';
import { MonthSwitcher } from '../components/month-switcher';
import { Onboarding } from '../components/onboarding';
import { ModeSetup } from '../components/mode-setup';
import { StatusIndicator } from '../components/status-indicator';
import { useFinanceData } from '../hooks/useFinanceData';
import { useLanguage } from '../hooks/useLanguage';
import { getModeLabel } from '../data/mock-data';
import { Category, CATEGORIES, Mode, Member } from '../types/finance';

export function Dashboard() {
  const { lang, t } = useLanguage();
  const navigate = useNavigate();

  const {
    mode,
    members,
    expenses,
    currentMonth,
    hasSeenOnboarding,
    setupComplete,
    includePersonalInBudget,
    setMode,
    addExpense,
    updateMember,
    addMember,
    removeMember,
    deleteExpense,
    setCurrentMonth,
    setMonthlyBudget,
    markOnboardingComplete,
    completeSetup,
    setIncludePersonalInBudget,
    calculateSettlements,
    getTotalExpenses,
    getMonthlyBudget,
    getRemainingBudget,
    getProjectedSavings,
    getSpendingPace,
    getExpenseSplitData,
    getCategoryBreakdownData,
    getBudgetVsSpendingData,
    getBudgetStatus,
    resetAllData,
  } = useFinanceData();

  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [isModeSetupOpen, setIsModeSetupOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all');

  // Show onboarding on first visit
  useEffect(() => {
    if (!hasSeenOnboarding) {
      setIsOnboardingOpen(true);
    }
  }, [hasSeenOnboarding]);

  // Show mode setup when mode is switched and setup is not complete
  useEffect(() => {
    if (!setupComplete && hasSeenOnboarding) {
      setIsModeSetupOpen(true);
    }
  }, [setupComplete, hasSeenOnboarding, mode]);

  const totalExpenses = getTotalExpenses();
  const budget = getMonthlyBudget();
  const remainingBudget = getRemainingBudget();
  const projectedSavings = getProjectedSavings();
  const budgetStatus = getBudgetStatus();
  const settlements = calculateSettlements();
  const splitData = getExpenseSplitData();
  const categoryData = getCategoryBreakdownData();
  const chartData = getBudgetVsSpendingData();
  const spendingPace = getSpendingPace();

  const getMemberName = (memberId: string) => {
    return members.find((m) => m.id === memberId)?.name || 'Unknown';
  };

  const handleAddExpense = (expense: any) => {
    addExpense(expense);
    toast.success('Expense added successfully!', {
      description: `$${expense.amount.toFixed(2)} for ${expense.description}`,
    });
  };

  const handleDeleteExpense = (expenseId: string, description: string, amount: number) => {
    if (window.confirm(`Delete "${description}"?`)) {
      deleteExpense(expenseId);
      toast.success('Expense deleted', {
        description: `$${amount.toFixed(2)} removed`,
      });
    }
  };

  const handleSetBudget = (newBudget: number | undefined) => {
    setMonthlyBudget(newBudget);
    if (newBudget) {
      toast.success('Budget updated!', {
        description: `Monthly budget set to $${newBudget.toLocaleString()}`,
      });
    } else {
      toast.success('Budget removed');
    }
  };

  const handleModeChange = (newMode: Mode) => {
    setMode(newMode);
    const modeLabels = {
      solo: t.modes.solo,
      couple: t.modes.couple,
      roommates: t.modes.roommates,
    };
    toast.success(`Switched to ${modeLabels[newMode]} mode`);
  };

  const handleOnboardingComplete = (selectedMode: Mode) => {
    // Set the selected mode from onboarding
    setMode(selectedMode);
    // Mark onboarding as seen
    markOnboardingComplete();
    setIsOnboardingOpen(false);
    toast.success(`${t.dashboard.welcomeToUsAndMoney}! 🎉`, {
      description: t.dashboard.letsStartTracking,
    });
  };

  const handleOnboardingSkip = () => {
    markOnboardingComplete();
    setIsOnboardingOpen(false);
  };

  const handleSetupComplete = (members: Member[]) => {
    completeSetup(members);
    setIsModeSetupOpen(false);
    toast.success(t.toast.setupComplete);
  };

  const handleSetupSkip = () => {
    setIsModeSetupOpen(false);
  };

  const handleIncludePersonalInBudgetChange = (include: boolean) => {
    setIncludePersonalInBudget(include);
    toast.success(`Personal expenses ${include ? 'included' : 'excluded'} in budget`);
  };

  const handleResetData = () => {
    if (window.confirm(t.settings.resetDataConfirm)) {
      resetAllData();
      toast.success(t.settings.resetDataSuccess);
      // Navigate to landing page after reset
      navigate('/');
    }
  };

  // Filter expenses by category
  const filteredExpenses = selectedCategory === 'all'
    ? expenses
    : expenses.filter((e) => e.category === selectedCategory);

  // Get unique categories from expenses
  const usedCategories = Array.from(new Set(expenses.map((e) => e.category).filter(Boolean))) as Category[];

  // Calculate metrics for stat cards
  const budgetUsagePercentage = budget && budget > 0 ? ((totalExpenses / budget) * 100).toFixed(0) : '0';
  const isOverBudget = budget ? totalExpenses > budget : false;
  const isOnTrack = budget ? spendingPace.projectedTotal <= budget : true;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Onboarding */}
      <Onboarding
        isOpen={isOnboardingOpen}
        onComplete={handleOnboardingComplete}
        onSkip={handleOnboardingSkip}
      />

      {/* Mode Setup */}
      {isModeSetupOpen && (
        <ModeSetup
          mode={mode}
          onComplete={handleSetupComplete}
        />
      )}

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/" className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-5 h-5" />
                <span className="hidden sm:inline text-sm">Back</span>
              </Link>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                  <Wallet className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-gray-900">Us&Money</span>
              </div>
            </div>
            <button className="p-2 text-gray-600 hover:text-gray-900 sm:hidden">
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header with Mode Selector and Month Switcher */}
        <div className="flex flex-col gap-4 mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-1">
                {getModeLabel(mode)} Dashboard
              </h1>
              <p className="text-gray-600">
                {mode === 'solo' 
                  ? t.dashboard.trackPersonalFinances
                  : mode === 'couple' 
                    ? t.dashboard.manageSharedExpensesPartner 
                    : t.dashboard.manageSharedExpensesRoommates
                }
              </p>
            </div>
            <ModeSelector mode={mode} onModeChange={handleModeChange} />
          </div>
          <div className="flex justify-end">
            <MonthSwitcher currentMonth={currentMonth} onMonthChange={setCurrentMonth} />
          </div>
        </div>

        {/* Budget Card */}
        <div className="mb-8">
          <BudgetCard
            budget={budget}
            totalExpenses={totalExpenses}
            mode={mode}
            budgetStatus={budgetStatus}
            includePersonalInBudget={includePersonalInBudget}
            onSetBudget={handleSetBudget}
            onToggleIncludePersonal={mode !== 'solo' ? handleIncludePersonalInBudgetChange : undefined}
          />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {budget ? (
            <>
              <StatCard
                title={t.dashboard.totalSpent}
                value={`$${totalExpenses.toLocaleString()}`}
                icon={DollarSign}
                trend={`${budgetUsagePercentage}% ${t.dashboard.ofBudget}`}
                trendUp={!isOverBudget}
                color={isOverBudget ? 'red' : 'purple'}
              />
              <StatCard
                title={t.dashboard.remainingBudget}
                value={`$${Math.abs(remainingBudget).toLocaleString()}`}
                icon={Wallet}
                trend={isOverBudget ? t.status.overBudget : `${(100 - Number(budgetUsagePercentage)).toFixed(0)}% ${t.budget.remaining}`}
                trendUp={!isOverBudget}
                color={isOverBudget ? 'red' : 'green'}
              />
              <StatCard
                title={t.dashboard.projectedSavings}
                value={`$${projectedSavings.toLocaleString()}`}
                icon={PiggyBank}
                trend={isOnTrack ? t.status.onTrack : 'Over pace'}
                trendUp={isOnTrack}
                color="green"
              />
            </>
          ) : (
            <>
              <StatCard
                title={t.dashboard.totalSpent}
                value={`$${totalExpenses.toLocaleString()}`}
                icon={DollarSign}
                color="purple"
              />
              <StatCard
                title={t.dashboard.dailyAverage}
                value={`$${spendingPace.dailyAverage.toFixed(0)}`}
                icon={TrendingUp}
                trend={currentMonth}
                trendUp={true}
                color="pink"
              />
              <StatCard
                title={t.dashboard.projectedTotal}
                value={`$${Math.round(spendingPace.projectedTotal).toLocaleString()}`}
                icon={TrendingDown}
                trend={t.dashboard.weeklySpend}
                trendUp={false}
                color="blue"
              />
            </>
          )}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <IncomeChart data={chartData} hasBudget={!!budget} />
          {mode === 'solo' ? (
            <CategoryChart data={categoryData} />
          ) : (
            <SplitChart data={splitData} mode={mode} />
          )}
        </div>

        {/* Settlements (only for couple/roommates) */}
        {mode !== 'solo' && (
          <div className="mb-8">
            <SettlementsCard settlements={settlements} members={members} />
          </div>
        )}

        {/* Member Manager (only for couple/roommates) */}
        {mode !== 'solo' && (
          <div className="mb-8">
            <MemberManager
              members={members}
              mode={mode}
              onUpdateMember={(id, name) => {
                updateMember(id, name);
                toast.success('Member updated');
              }}
              onAddMember={(name) => {
                addMember(name);
                toast.success(`${name} added to the group`);
              }}
              onRemoveMember={(id) => {
                const member = members.find((m) => m.id === id);
                removeMember(id);
                toast.success(`${member?.name || 'Member'} removed`);
              }}
            />
          </div>
        )}

        {/* Recent Transactions */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-semibold text-gray-900">{t.dashboard.recentTransactions}</h3>
            <button
              onClick={() => setIsAddExpenseOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-medium hover:shadow-lg transition-all"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">{t.expenses.addExpense}</span>
            </button>
          </div>

          {/* Category Filter */}
          {usedCategories.length > 0 && (
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">Filter by category:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    selectedCategory === 'all'
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All ({expenses.length})
                </button>
                {CATEGORIES.filter((cat) => usedCategories.includes(cat)).map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                      selectedCategory === category
                        ? 'bg-purple-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {category} ({expenses.filter((e) => e.category === category).length})
                  </button>
                ))}
              </div>
            </div>
          )}

          {expenses.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="w-8 h-8 text-purple-600" />
              </div>
              <p className="text-gray-900 font-semibold mb-2">{t.dashboard.noExpenses}</p>
              <p className="text-sm text-gray-500 mb-6">
                {budget 
                  ? `$${budget.toLocaleString()} ${t.dashboard.budgetedThisMonth}`
                  : t.dashboard.addFirstExpense
                }
              </p>
              <button
                onClick={() => setIsAddExpenseOpen(true)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
              >
                <Plus className="w-5 h-5" />
                {t.expenses.addExpense}
              </button>
            </div>
          ) : filteredExpenses.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600 mb-2">{t.dashboard.noExpensesInCategory}</p>
              <button
                onClick={() => setSelectedCategory('all')}
                className="text-purple-600 hover:text-purple-700 font-medium text-sm"
              >
                {t.dashboard.showAllExpenses}
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredExpenses.slice(0, 15).map((expense) => (
                <div
                  key={expense.id}
                  className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors group"
                >
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{expense.description}</p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      {expense.category && (
                        <>
                          <span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded text-xs font-medium">
                            {expense.category}
                          </span>
                          <span className="text-gray-300">•</span>
                        </>
                      )}
                      <span className="text-sm text-purple-600">
                        Paid by {getMemberName(expense.paidBy)}
                      </span>
                      {mode !== 'solo' && expense.shared && (
                        <>
                          <span className="text-gray-300">•</span>
                          <span className="text-sm text-gray-500">
                            {expense.splitType === 'equal' ? 'Split equally' : 'Custom split'}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    <div>
                      <p className="font-semibold text-gray-900">
                        ${expense.amount.toFixed(2)}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(expense.date).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDeleteExpense(expense.id, expense.description, expense.amount)}
                      className="opacity-0 group-hover:opacity-100 p-2 text-red-600 hover:bg-red-50 rounded-lg transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Reset Data Section */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="bg-white rounded-xl shadow-sm border border-red-200 p-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">{t.settings.resetData}</h3>
                <p className="text-sm text-gray-600">{t.settings.resetDataWarning}</p>
              </div>
              <button
                onClick={handleResetData}
                className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                {t.settings.resetData}
              </button>
            </div>
          </div>
        </div>

        {/* Quick Actions - Mobile Floating Button */}
        <div className="fixed bottom-6 right-6 lg:hidden">
          <button
            onClick={() => setIsAddExpenseOpen(true)}
            className="w-14 h-14 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-full shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>
      </main>

      {/* Add Expense Modal */}
      <AddExpenseModal
        isOpen={isAddExpenseOpen}
        onClose={() => setIsAddExpenseOpen(false)}
        onAdd={handleAddExpense}
        members={members}
      />
    </div>
  );
}