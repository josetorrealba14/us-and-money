'use client';

import { Link } from 'react-router';
import { ArrowLeft } from 'lucide-react';
import { LanguageToggle } from '../components/language-toggle';
import { useLanguage } from '../hooks/useLanguage';

export function Settings() {
  const { lang, t } = useLanguage();

  console.log('🟣 Settings RENDER - lang:', lang);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link
              to="/dashboard"
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </Link>
            <h1 className="text-xl font-bold text-gray-900">{t.settings.title}</h1>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="space-y-6">
          {/* Language Toggle */}
          <LanguageToggle />
        </div>
      </div>
    </div>
  );
}