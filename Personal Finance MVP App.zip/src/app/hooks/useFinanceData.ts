import { useState, useEffect } from 'react';
import { Mode, Member, Expense, AppState, Balance, Settlement, MonthlyData, ModeWorkspace } from '../types/finance';
import { getCurrentMonthKey } from '../utils/date-utils';

const STORAGE_KEY = 'usmoney_finance_data';

// Get "You" translated based on current language
const getYouName = (): string => {
  try {
    const lang = localStorage.getItem('usmoney-language') || 'en';
    return lang === 'es' ? 'Tú' : 'You';
  } catch {
    return 'You';
  }
};

const getDefaultMembers = (mode: Mode): Member[] => {
  const youName = getYouName();
  switch (mode) {
    case 'solo':
      return [{ id: 'user1', name: youName }];
    case 'couple':
      // Start empty - will be filled during setup
      return [];
    case 'roommates':
      // Start empty - will be filled during setup
      return [];
  }
};

const createDefaultWorkspace = (mode: Mode): ModeWorkspace => {
  return {
    members: getDefaultMembers(mode),
    months: {},
    setupComplete: mode === 'solo', // Solo is auto-setup
    includePersonalInBudget: true, // Default to including all expenses
  };
};

const loadData = (): AppState => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const data = JSON.parse(stored);
      // Ensure all workspaces exist
      return {
        currentMode: data.currentMode || 'solo',
        workspaces: {
          solo: data.workspaces?.solo || createDefaultWorkspace('solo'),
          couple: data.workspaces?.couple || createDefaultWorkspace('couple'),
          roommates: data.workspaces?.roommates || createDefaultWorkspace('roommates'),
        },
        hasSeenOnboarding: data.hasSeenOnboarding || false,
      };
    }
  } catch (error) {
    console.error('Failed to load data:', error);
  }
  return {
    currentMode: 'solo',
    workspaces: {
      solo: createDefaultWorkspace('solo'),
      couple: createDefaultWorkspace('couple'),
      roommates: createDefaultWorkspace('roommates'),
    },
    hasSeenOnboarding: false,
  };
};

const saveData = (data: AppState) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Failed to save data:', error);
  }
};

export function useFinanceData() {
  const [state, setState] = useState<AppState>(loadData);
  const [currentMonth, setCurrentMonth] = useState<string>(getCurrentMonthKey());

  useEffect(() => {
    saveData(state);
  }, [state]);

  // Get current workspace
  const getCurrentWorkspace = (): ModeWorkspace => {
    return state.workspaces[state.currentMode];
  };

  const getCurrentMonthData = (): MonthlyData => {
    const workspace = getCurrentWorkspace();
    return workspace.months[currentMonth] || { expenses: [] };
  };

  const setMode = (mode: Mode) => {
    setState((prev) => ({
      ...prev,
      currentMode: mode,
    }));
  };

  const addExpense = (expense: Expense) => {
    setState((prev) => {
      const workspace = prev.workspaces[prev.currentMode];
      const monthData = workspace.months[currentMonth] || { expenses: [] };
      return {
        ...prev,
        workspaces: {
          ...prev.workspaces,
          [prev.currentMode]: {
            ...workspace,
            months: {
              ...workspace.months,
              [currentMonth]: {
                ...monthData,
                expenses: [expense, ...monthData.expenses],
              },
            },
          },
        },
      };
    });
  };

  const updateMember = (memberId: string, name: string) => {
    setState((prev) => {
      const workspace = prev.workspaces[prev.currentMode];
      return {
        ...prev,
        workspaces: {
          ...prev.workspaces,
          [prev.currentMode]: {
            ...workspace,
            members: workspace.members.map((m) => (m.id === memberId ? { ...m, name } : m)),
          },
        },
      };
    });
  };

  const addMember = (name: string) => {
    setState((prev) => {
      const workspace = prev.workspaces[prev.currentMode];
      const newId = `user${workspace.members.length + 1}`;
      return {
        ...prev,
        workspaces: {
          ...prev.workspaces,
          [prev.currentMode]: {
            ...workspace,
            members: [...workspace.members, { id: newId, name }],
          },
        },
      };
    });
  };

  const removeMember = (memberId: string) => {
    setState((prev) => {
      const workspace = prev.workspaces[prev.currentMode];
      return {
        ...prev,
        workspaces: {
          ...prev.workspaces,
          [prev.currentMode]: {
            ...workspace,
            members: workspace.members.filter((m) => m.id !== memberId),
          },
        },
      };
    });
  };

  const deleteExpense = (expenseId: string) => {
    setState((prev) => {
      const workspace = prev.workspaces[prev.currentMode];
      const monthData = workspace.months[currentMonth] || { expenses: [] };
      return {
        ...prev,
        workspaces: {
          ...prev.workspaces,
          [prev.currentMode]: {
            ...workspace,
            months: {
              ...workspace.months,
              [currentMonth]: {
                ...monthData,
                expenses: monthData.expenses.filter((e) => e.id !== expenseId),
              },
            },
          },
        },
      };
    });
  };

  const setMonthlyBudget = (budget: number | undefined) => {
    setState((prev) => {
      const workspace = prev.workspaces[prev.currentMode];
      const monthData = workspace.months[currentMonth] || { expenses: [] };
      return {
        ...prev,
        workspaces: {
          ...prev.workspaces,
          [prev.currentMode]: {
            ...workspace,
            months: {
              ...workspace.months,
              [currentMonth]: {
                ...monthData,
                budget,
              },
            },
          },
        },
      };
    });
  };

  const markOnboardingComplete = () => {
    setState((prev) => ({
      ...prev,
      hasSeenOnboarding: true,
    }));
  };

  const completeSetup = (members: Member[]) => {
    setState((prev) => {
      const workspace = prev.workspaces[prev.currentMode];
      return {
        ...prev,
        workspaces: {
          ...prev.workspaces,
          [prev.currentMode]: {
            ...workspace,
            members,
            setupComplete: true,
          },
        },
      };
    });
  };

  const setIncludePersonalInBudget = (include: boolean) => {
    setState((prev) => {
      const workspace = prev.workspaces[prev.currentMode];
      return {
        ...prev,
        workspaces: {
          ...prev.workspaces,
          [prev.currentMode]: {
            ...workspace,
            includePersonalInBudget: include,
          },
        },
      };
    });
  };

  // Reset all app data (except language preference)
  const resetAllData = () => {
    // Clear localStorage except language preference
    const language = localStorage.getItem('usmoney-language');
    localStorage.clear();
    if (language) {
      localStorage.setItem('usmoney-language', language);
    }
    
    // Reset state to initial state (fresh start)
    const initialState: AppState = {
      currentMode: 'solo',
      workspaces: {
        solo: createDefaultWorkspace('solo'),
        couple: createDefaultWorkspace('couple'),
        roommates: createDefaultWorkspace('roommates'),
      },
      hasSeenOnboarding: false,
    };
    setState(initialState);
    
    // Return true to indicate reset was successful
    return true;
  };

  // Get current workspace data
  const workspace = getCurrentWorkspace();
  const members = workspace.members;
  const expenses = getCurrentMonthData().expenses;
  const monthlyBudget = getCurrentMonthData().budget;
  const setupComplete = workspace.setupComplete || false;
  const includePersonalInBudget = workspace.includePersonalInBudget !== false; // Default true

  // Calculate balances for each member (for settlements only)
  const calculateBalances = (): Balance[] => {
    const monthData = getCurrentMonthData();
    const balances: { [memberId: string]: number } = {};

    // Initialize balances
    members.forEach((member) => {
      balances[member.id] = 0;
    });

    // Process each expense
    monthData.expenses.forEach((expense) => {
      if (!expense.shared) {
        // Not shared, only the payer is affected
        return;
      }

      const totalAmount = expense.amount;
      const paidBy = expense.paidBy;

      if (expense.splitType === 'equal') {
        // Equal split among all members
        const perPersonShare = totalAmount / members.length;

        members.forEach((member) => {
          if (member.id === paidBy) {
            // Payer paid full amount but only owes their share
            balances[member.id] += totalAmount - perPersonShare;
          } else {
            // Others owe their share
            balances[member.id] -= perPersonShare;
          }
        });
      } else if (expense.splitType === 'percent' && expense.splits) {
        // Percentage-based split
        members.forEach((member) => {
          const memberShare = expense.splits![member.id] || 0;
          const memberAmount = (totalAmount * memberShare) / 100;

          if (member.id === paidBy) {
            balances[member.id] += totalAmount - memberAmount;
          } else {
            balances[member.id] -= memberAmount;
          }
        });
      }
    });

    return Object.entries(balances).map(([memberId, balance]) => ({
      memberId,
      balance,
    }));
  };

  // Calculate who owes whom
  const calculateSettlements = (): Settlement[] => {
    const balances = calculateBalances();
    const settlements: Settlement[] = [];

    // Separate creditors (positive balance) and debtors (negative balance)
    const creditors = balances
      .filter((b) => b.balance > 0.01)
      .map((b) => ({ ...b }))
      .sort((a, b) => b.balance - a.balance);

    const debtors = balances
      .filter((b) => b.balance < -0.01)
      .map((b) => ({ ...b, balance: -b.balance }))
      .sort((a, b) => b.balance - a.balance);

    let i = 0;
    let j = 0;

    while (i < creditors.length && j < debtors.length) {
      const creditor = creditors[i];
      const debtor = debtors[j];

      const amount = Math.min(creditor.balance, debtor.balance);

      if (amount > 0.01) {
        settlements.push({
          from: debtor.memberId,
          to: creditor.memberId,
          amount: Math.round(amount * 100) / 100,
        });
      }

      creditor.balance -= amount;
      debtor.balance -= amount;

      if (creditor.balance < 0.01) i++;
      if (debtor.balance < 0.01) j++;
    }

    return settlements;
  };

  // Budget-based calculations
  const getTotalExpenses = (): number => {
    const monthData = getCurrentMonthData();
    
    // Filter expenses based on includePersonalInBudget setting (only for couple/roommates)
    const expensesToCount = monthData.expenses.filter((expense) => {
      if (state.currentMode === 'solo') {
        // In solo mode, always count all expenses
        return true;
      }
      
      // In couple/roommates mode, check the setting
      if (includePersonalInBudget) {
        // Count all expenses (shared + personal)
        return true;
      } else {
        // Only count shared expenses
        return expense.shared;
      }
    });
    
    return expensesToCount.reduce((sum, expense) => sum + expense.amount, 0);
  };

  const getMonthlyBudget = (): number | undefined => {
    return monthlyBudget;
  };

  const getRemainingBudget = (): number => {
    if (!monthlyBudget) return 0;
    return monthlyBudget - getTotalExpenses();
  };

  const getProjectedSavings = (): number => {
    if (!monthlyBudget) return 0;
    const remaining = getRemainingBudget();
    return remaining > 0 ? remaining : 0;
  };

  const getBudgetProgress = (): { used: number; remaining: number; percentage: number; isOver: boolean } | null => {
    const budget = getMonthlyBudget();
    if (!budget) return null;

    const expenses = getTotalExpenses();
    const percentage = (expenses / budget) * 100;
    const remaining = budget - expenses;

    return {
      used: expenses,
      remaining,
      percentage: Math.min(percentage, 100),
      isOver: expenses > budget,
    };
  };

  // Calculate spending pace (how much per day on average)
  const getSpendingPace = (): { dailyAverage: number; projectedTotal: number } => {
    const now = new Date();
    const monthData = getCurrentMonthData();
    
    // Get all expenses for the current month
    const currentMonthExpenses = monthData.expenses.filter((expense) => {
      const expenseDate = new Date(expense.date);
      return (
        expenseDate.getMonth() === now.getMonth() &&
        expenseDate.getFullYear() === now.getFullYear()
      );
    });

    const totalSpent = currentMonthExpenses.reduce((sum, e) => sum + e.amount, 0);
    const currentDay = now.getDate();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();

    const dailyAverage = currentDay > 0 ? totalSpent / currentDay : 0;
    const projectedTotal = dailyAverage * daysInMonth;

    return { dailyAverage, projectedTotal };
  };

  // Get expense split data for chart
  const getExpenseSplitData = () => {
    const monthData = getCurrentMonthData();
    const splitData: { [memberId: string]: number } = {};

    members.forEach((member) => {
      splitData[member.id] = 0;
    });

    monthData.expenses.forEach((expense) => {
      if (!expense.shared) {
        // If not shared, all expense goes to the payer
        splitData[expense.paidBy] = (splitData[expense.paidBy] || 0) + expense.amount;
      } else {
        if (expense.splitType === 'equal') {
          const perPerson = expense.amount / members.length;
          members.forEach((member) => {
            splitData[member.id] = (splitData[member.id] || 0) + perPerson;
          });
        } else if (expense.splitType === 'percent' && expense.splits) {
          members.forEach((member) => {
            const share = expense.splits![member.id] || 0;
            const amount = (expense.amount * share) / 100;
            splitData[member.id] = (splitData[member.id] || 0) + amount;
          });
        }
      }
    });

    const colors = ['#8b5cf6', '#ec4899', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

    return members.map((member, index) => ({
      name: member.name,
      value: Math.round(splitData[member.id] * 100) / 100,
      color: colors[index % colors.length],
    }));
  };

  // Get budget vs actual spending data for chart
  const getBudgetVsSpendingData = () => {
    if (!monthlyBudget) {
      // If no budget, just show weekly spending
      const totalExpenses = getTotalExpenses();
      return [
        { name: 'Week 1', budget: 0, actual: totalExpenses * 0.22 },
        { name: 'Week 2', budget: 0, actual: totalExpenses * 0.28 },
        { name: 'Week 3', budget: 0, actual: totalExpenses * 0.26 },
        { name: 'Week 4', budget: 0, actual: totalExpenses * 0.24 },
      ];
    }

    const weeklyBudget = monthlyBudget / 4;
    const totalExpenses = getTotalExpenses();

    // Simple weekly breakdown of actual spending
    return [
      { name: 'Week 1', budget: weeklyBudget, actual: totalExpenses * 0.22 },
      { name: 'Week 2', budget: weeklyBudget, actual: totalExpenses * 0.28 },
      { name: 'Week 3', budget: weeklyBudget, actual: totalExpenses * 0.26 },
      { name: 'Week 4', budget: weeklyBudget, actual: totalExpenses * 0.24 },
    ];
  };

  // Calculate budget status based on time and spending
  const getBudgetStatus = (): 'on-track' | 'watch' | 'over' | null => {
    if (!monthlyBudget) return null;

    const now = new Date();
    const currentDay = now.getDate();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    const monthProgress = currentDay / daysInMonth; // Percentage of month passed

    const totalExpenses = getTotalExpenses();
    const budgetProgress = totalExpenses / monthlyBudget; // Percentage of budget used

    // If over budget, always show "over"
    if (totalExpenses > monthlyBudget) {
      return 'over';
    }

    // If spending pace is significantly ahead of time, show warning
    // Allow 10% tolerance before warning
    if (budgetProgress > monthProgress + 0.1) {
      return 'watch';
    }

    // Otherwise, on track
    return 'on-track';
  };

  // Get category breakdown data for chart (Solo mode)
  const getCategoryBreakdownData = () => {
    const monthData = getCurrentMonthData();
    const categoryTotals: { [category: string]: number } = {};

    monthData.expenses.forEach((expense) => {
      const category = expense.category || 'Other';
      categoryTotals[category] = (categoryTotals[category] || 0) + expense.amount;
    });

    const colors = ['#8b5cf6', '#ec4899', '#f97316', '#10b981', '#3b82f6', '#eab308'];
    
    return Object.entries(categoryTotals)
      .map(([category, total], index) => ({
        name: category,
        value: Math.round(total * 100) / 100,
        color: colors[index % colors.length],
      }))
      .sort((a, b) => b.value - a.value); // Sort by value descending
  };

  return {
    mode: state.currentMode,
    members,
    expenses,
    currentMonth,
    hasSeenOnboarding: state.hasSeenOnboarding,
    setMode,
    addExpense,
    updateMember,
    addMember,
    removeMember,
    deleteExpense,
    setCurrentMonth,
    setMonthlyBudget,
    markOnboardingComplete,
    completeSetup,
    setIncludePersonalInBudget,
    resetAllData,
    calculateBalances,
    calculateSettlements,
    getTotalExpenses,
    getMonthlyBudget,
    getRemainingBudget,
    getProjectedSavings,
    getBudgetProgress,
    getSpendingPace,
    getExpenseSplitData,
    getCategoryBreakdownData,
    getBudgetVsSpendingData,
    getBudgetStatus,
    setupComplete,
    includePersonalInBudget,
  };
}