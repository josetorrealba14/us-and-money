import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { translations, Language } from '../i18n/translations';

interface LanguageContextType {
  lang: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.en;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const STORAGE_KEY = 'usmoney-language';

// Get initial language from localStorage (for SSR safety)
function getInitialLanguage(): Language {
  if (typeof window === 'undefined') return 'en';
  try {
    const stored = localStorage.getItem(STORAGE_KEY) as Language | null;
    console.log('📖 Reading initial language from localStorage:', stored);
    return (stored === 'en' || stored === 'es') ? stored : 'en';
  } catch {
    return 'en';
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Language>(getInitialLanguage);

  console.log('🟣 LanguageProvider RENDER - lang:', lang);

  // Sync with localStorage on changes
  useEffect(() => {
    console.log('💾 Saving to localStorage:', lang);
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch (error) {
      console.error('Failed to save language to localStorage:', error);
    }
  }, [lang]);

  const setLanguage = useCallback((newLang: Language) => {
    console.log('🔄 setLanguage called:', newLang);
    setLang((prevLang) => {
      console.log('🔄 setLang callback - from:', prevLang, 'to:', newLang);
      return newLang;
    });
  }, []);

  return (
    <LanguageContext.Provider value={{ lang, setLanguage, t: translations[lang] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    console.error('❌ [useLanguage] NO CONTEXT - Provider is missing!');
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}