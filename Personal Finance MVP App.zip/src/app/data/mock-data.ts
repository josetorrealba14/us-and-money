// Mock data for the finance MVP

export type Mode = 'solo' | 'couple' | 'roommates';

export interface Transaction {
  id: string;
  description: string;
  amount: number;
  category: string;
  person: string;
  date: string;
}

export interface MonthlyData {
  income: number;
  expenses: number;
  savings: number;
  transactions: Transaction[];
  splitData: { name: string; value: number; color: string }[];
}

export interface ModeData {
  solo: MonthlyData;
  couple: MonthlyData;
  roommates: MonthlyData;
}

export const mockData: ModeData = {
  solo: {
    income: 3500,
    expenses: 2680,
    savings: 820,
    transactions: [
      { id: '1', description: 'Rent', amount: 1200, category: 'Housing', person: 'You', date: '2026-02-01' },
      { id: '2', description: 'Groceries', amount: 420, category: 'Food', person: 'You', date: '2026-02-05' },
      { id: '3', description: 'Gym membership', amount: 60, category: 'Health', person: 'You', date: '2026-02-10' },
      { id: '4', description: 'Streaming services', amount: 45, category: 'Entertainment', person: 'You', date: '2026-02-12' },
      { id: '5', description: 'Coffee & restaurants', amount: 280, category: 'Food', person: 'You', date: '2026-02-15' },
      { id: '6', description: 'Transportation', amount: 175, category: 'Transport', person: 'You', date: '2026-02-18' },
      { id: '7', description: 'Shopping', amount: 350, category: 'Shopping', person: 'You', date: '2026-02-20' },
      { id: '8', description: 'Utilities', amount: 150, category: 'Housing', person: 'You', date: '2026-02-22' },
    ],
    splitData: [
      { name: 'You', value: 100, color: '#8b5cf6' },
    ],
  },
  couple: {
    income: 6800,
    expenses: 4950,
    savings: 1850,
    transactions: [
      { id: '1', description: 'Rent', amount: 1800, category: 'Housing', person: 'Joint', date: '2026-02-01' },
      { id: '2', description: 'Groceries', amount: 680, category: 'Food', person: 'Alex', date: '2026-02-05' },
      { id: '3', description: 'Date night', amount: 120, category: 'Entertainment', person: 'Jordan', date: '2026-02-08' },
      { id: '4', description: 'Gym (2 memberships)', amount: 110, category: 'Health', person: 'Joint', date: '2026-02-10' },
      { id: '5', description: 'Gas', amount: 140, category: 'Transport', person: 'Alex', date: '2026-02-12' },
      { id: '6', description: 'Streaming & subscriptions', amount: 75, category: 'Entertainment', person: 'Joint', date: '2026-02-14' },
      { id: '7', description: 'Coffee shops', amount: 95, category: 'Food', person: 'Jordan', date: '2026-02-16' },
      { id: '8', description: 'Utilities', amount: 220, category: 'Housing', person: 'Joint', date: '2026-02-18' },
      { id: '9', description: 'Shopping', amount: 450, category: 'Shopping', person: 'Jordan', date: '2026-02-20' },
      { id: '10', description: 'Car insurance', amount: 260, category: 'Transport', person: 'Alex', date: '2026-02-22' },
      { id: '11', description: 'Groceries', amount: 580, category: 'Food', person: 'Jordan', date: '2026-02-23' },
      { id: '12', description: 'Phone bills', amount: 120, category: 'Bills', person: 'Joint', date: '2026-02-24' },
    ],
    splitData: [
      { name: 'Alex', value: 1570, color: '#8b5cf6' },
      { name: 'Jordan', value: 1845, color: '#ec4899' },
      { name: 'Joint', value: 1535, color: '#6366f1' },
    ],
  },
  roommates: {
    income: 9500,
    expenses: 7340,
    savings: 2160,
    transactions: [
      { id: '1', description: 'Rent', amount: 2700, category: 'Housing', person: 'Split', date: '2026-02-01' },
      { id: '2', description: 'Utilities', amount: 360, category: 'Housing', person: 'Split', date: '2026-02-03' },
      { id: '3', description: 'Groceries (shared)', amount: 420, category: 'Food', person: 'Sam', date: '2026-02-05' },
      { id: '4', description: 'Internet', amount: 90, category: 'Bills', person: 'Split', date: '2026-02-07' },
      { id: '5', description: 'Cleaning supplies', amount: 65, category: 'Home', person: 'Taylor', date: '2026-02-09' },
      { id: '6', description: 'Groceries (personal)', amount: 280, category: 'Food', person: 'Chris', date: '2026-02-11' },
      { id: '7', description: 'Takeout (shared)', amount: 145, category: 'Food', person: 'Taylor', date: '2026-02-13' },
      { id: '8', description: 'Groceries (shared)', amount: 390, category: 'Food', person: 'Chris', date: '2026-02-15' },
      { id: '9', description: 'Party supplies', amount: 180, category: 'Entertainment', person: 'Split', date: '2026-02-17' },
      { id: '10', description: 'Furniture (shared)', amount: 540, category: 'Home', person: 'Split', date: '2026-02-19' },
      { id: '11', description: 'Groceries (shared)', amount: 350, category: 'Food', person: 'Sam', date: '2026-02-21' },
      { id: '12', description: 'Home repairs', amount: 220, category: 'Home', person: 'Taylor', date: '2026-02-23' },
    ],
    splitData: [
      { name: 'Sam', value: 2320, color: '#8b5cf6' },
      { name: 'Taylor', value: 2410, color: '#ec4899' },
      { name: 'Chris', value: 2610, color: '#06b6d4' },
    ],
  },
};

export const incomeVsExpensesData = (mode: Mode) => {
  const data = mockData[mode];
  return [
    { name: 'Week 1', income: data.income * 0.25, expenses: data.expenses * 0.22 },
    { name: 'Week 2', income: data.income * 0.25, expenses: data.expenses * 0.28 },
    { name: 'Week 3', income: data.income * 0.25, expenses: data.expenses * 0.26 },
    { name: 'Week 4', income: data.income * 0.25, expenses: data.expenses * 0.24 },
  ];
};

export const getModeLabel = (mode: Mode): string => {
  const labels = {
    solo: 'Solo',
    couple: 'Couple',
    roommates: 'Roommates',
  };
  return labels[mode];
};

export const getModeDescription = (mode: Mode): string => {
  const descriptions = {
    solo: 'Track your personal finances',
    couple: 'Manage expenses with your partner',
    roommates: 'Split costs with your housemates',
  };
  return descriptions[mode];
};