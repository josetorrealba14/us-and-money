'use client';

import { Languages } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import { Language } from '../i18n/translations';
import { toast } from 'sonner';

interface LanguageToggleProps {
  compact?: boolean;
}

export function LanguageToggle({ compact = false }: LanguageToggleProps) {
  const { lang, setLanguage, t } = useLanguage();

  console.log('🎯 LanguageToggle render - lang:', lang, 'setLanguage:', typeof setLanguage);

  const handleLanguageChange = (newLang: Language) => {
    console.log('🚀 handleLanguageChange START:', { current: lang, new: newLang });
    setLanguage(newLang);
    console.log('🚀 handleLanguageChange AFTER setLanguage');
    toast.success(t.toast?.languageChanged || 'Language changed');
  };

  if (compact) {
    // Compact toggle for header - SINGLE BUTTON that toggles
    return (
      <button
        onClick={(e) => {
          console.log('🔥 TOGGLE BUTTON CLICKED! Current lang:', lang);
          e.preventDefault();
          e.stopPropagation();
          const newLang = lang === 'en' ? 'es' : 'en';
          console.log('🚀 Toggling from', lang, 'to', newLang);
          handleLanguageChange(newLang);
          console.log('✅ After setLanguage');
        }}
        className="px-4 py-2 bg-white/10 backdrop-blur-sm rounded-lg text-white hover:bg-white/20 transition-all text-sm font-medium"
        type="button"
      >
        {lang === 'en' ? 'EN 🇺🇸' : 'ES 🇪🇸'}
      </button>
    );
  }

  // Full toggle for settings
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
          <Languages className="w-5 h-5 text-purple-600" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-gray-900 mb-1">{t.settings.language}</h3>
          <p className="text-sm text-gray-500 mb-4">{t.settings.selectLanguage}</p>
          <div className="flex gap-3">
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                handleLanguageChange('en');
              }}
              className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
                lang === 'en'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              type="button"
            >
              🇺🇸 English
            </button>
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                handleLanguageChange('es');
              }}
              className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
                lang === 'es'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              type="button"
            >
              🇪🇸 Español
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}