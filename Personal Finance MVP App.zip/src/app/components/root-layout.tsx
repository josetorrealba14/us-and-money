'use client';

import { Outlet } from 'react-router';

export function RootLayout() {
  return <Outlet />;
}