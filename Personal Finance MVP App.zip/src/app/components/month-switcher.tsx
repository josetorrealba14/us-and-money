import { ChevronLeft, ChevronRight } from 'lucide-react';
import { getMonthLabel, getPreviousMonthKey, getNextMonthKey, isCurrentMonth } from '../utils/date-utils';

interface MonthSwitcherProps {
  currentMonth: string;
  onMonthChange: (month: string) => void;
}

export function MonthSwitcher({ currentMonth, onMonthChange }: MonthSwitcherProps) {
  const handlePrevious = () => {
    onMonthChange(getPreviousMonthKey(currentMonth));
  };

  const handleNext = () => {
    onMonthChange(getNextMonthKey(currentMonth));
  };

  return (
    <div className="flex items-center gap-2 bg-white rounded-lg border border-gray-200 px-2 py-1">
      <button
        onClick={handlePrevious}
        className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
        aria-label="Previous month"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>
      <div className="px-3 py-1 min-w-[140px] text-center">
        <span className="text-sm font-medium text-gray-900">
          {getMonthLabel(currentMonth)}
        </span>
        {isCurrentMonth(currentMonth) && (
          <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-700">
            Current
          </span>
        )}
      </div>
      <button
        onClick={handleNext}
        className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
        aria-label="Next month"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}
