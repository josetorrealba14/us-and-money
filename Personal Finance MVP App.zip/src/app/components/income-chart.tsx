import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useLanguage } from '../hooks/useLanguage';

interface BudgetChartProps {
  data: { name: string; budget: number; actual: number }[];
  hasBudget: boolean;
}

export function IncomeChart({ data, hasBudget }: BudgetChartProps) {
  const { t } = useLanguage();
  
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <h3 className="font-semibold text-gray-900 mb-4">
        {hasBudget ? t.dashboard.budgetVsSpending : t.dashboard.weeklySpend}
      </h3>
      <ResponsiveContainer width="100%" height={250}>
        <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
          <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="#9ca3af" />
          <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" />
          <Tooltip
            contentStyle={{
              backgroundColor: '#fff',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              fontSize: '14px',
            }}
            formatter={(value: number) => `$${value.toFixed(0)}`}
          />
          <Legend wrapperStyle={{ fontSize: '14px' }} />
          {hasBudget && (
            <Bar dataKey="budget" fill="#10b981" name={t.dashboard.budget} radius={[8, 8, 0, 0]} />
          )}
          <Bar dataKey="actual" fill="#8b5cf6" name={t.dashboard.actual} radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}