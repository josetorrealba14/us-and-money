import { useState } from 'react';
import { X } from 'lucide-react';
import type { Expense, Member, Category, SplitType } from '../types/finance';
import { CATEGORIES } from '../types/finance';
import { useLanguage } from '../hooks/useLanguage';

interface AddExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (expense: Expense) => void;
  members: Member[];
}

export function AddExpenseModal({ isOpen, onClose, onAdd, members }: AddExpenseModalProps) {
  const { t } = useLanguage();
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [paidBy, setPaidBy] = useState(members[0]?.id || '');
  const [shared, setShared] = useState(true);
  const [splitType, setSplitType] = useState<SplitType>('equal');
  const [category, setCategory] = useState<Category | ''>('');
  const [splits, setSplits] = useState<{ [memberId: string]: number }>(
    members.reduce((acc, m) => ({ ...acc, [m.id]: 0 }), {})
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!amount || !description || !paidBy) {
      alert('Please fill in all required fields');
      return;
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    // Validate percent splits if needed
    if (shared && splitType === 'percent') {
      const total = Object.values(splits).reduce((sum, val) => sum + val, 0);
      if (Math.abs(total - 100) > 0.01) {
        alert(t.expenses.percentageMustTotal100);
        return;
      }
    }

    const expense: Expense = {
      id: Date.now().toString(),
      amount: parsedAmount,
      description,
      date,
      paidBy,
      shared,
      splitType: shared && members.length > 1 ? splitType : 'equal',
      category: category || undefined,
      splits: shared && splitType === 'percent' ? splits : undefined,
    };

    onAdd(expense);
    setAmount('');
    setDescription('');
    setDate(new Date().toISOString().split('T')[0]);
    setPaidBy(members[0]?.id || '');
    setShared(true);
    setSplitType('equal');
    setCategory('');
    setSplits(members.reduce((acc, m) => ({ ...acc, [m.id]: 0 }), {}));
    onClose();
  };

  const handleSplitChange = (memberId: string, value: string) => {
    setSplits((prev) => ({
      ...prev,
      [memberId]: parseFloat(value) || 0,
    }));
  };

  const distributeEqually = () => {
    const equalSplit = 100 / members.length;
    setSplits(
      members.reduce((acc, m) => ({ ...acc, [m.id]: equalSplit }), {})
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">{t.expenses.addExpense}</h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t.expenses.amount} <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-semibold">
                $
              </span>
              <input
                type="number"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                placeholder="0.00"
                required
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t.expenses.description} <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
              placeholder="e.g., Groceries"
              required
            />
          </div>

          {/* Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t.expenses.date} <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
              required
            />
          </div>

          {/* Paid By */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t.expenses.paidBy} <span className="text-red-500">*</span>
            </label>
            <select
              value={paidBy}
              onChange={(e) => setPaidBy(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
              required
            >
              {members.map((member) => (
                <option key={member.id} value={member.id}>
                  {member.name}
                </option>
              ))}
            </select>
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t.expenses.category} <span className="text-gray-400">(optional)</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as Category | '')}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
            >
              <option value="">{t.expenses.selectCategory}</option>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Shared Expense */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <span className="text-sm font-medium text-gray-700">{t.expenses.shared}?</span>
            <button
              type="button"
              onClick={() => setShared(!shared)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                shared ? 'bg-purple-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  shared ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Split Type (only if shared) */}
          {shared && members.length > 1 && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t.expenses.splitType}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setSplitType('equal')}
                    className={`px-4 py-3 rounded-lg border-2 font-medium transition-all ${
                      splitType === 'equal'
                        ? 'border-purple-600 bg-purple-50 text-purple-600'
                        : 'border-gray-300 text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    {t.expenses.equalSplit}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSplitType('percent')}
                    className={`px-4 py-3 rounded-lg border-2 font-medium transition-all ${
                      splitType === 'percent'
                        ? 'border-purple-600 bg-purple-50 text-purple-600'
                        : 'border-gray-300 text-gray-700 hover:border-gray-400'
                    }`}
                  >
                    {t.expenses.customSplit}
                  </button>
                </div>
              </div>

              {/* Percentage Splits */}
              {splitType === 'percent' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="block text-sm font-medium text-gray-700">
                      {t.expenses.customSplit}
                    </label>
                    <button
                      type="button"
                      onClick={distributeEqually}
                      className="text-xs text-purple-600 hover:text-purple-700 font-medium"
                    >
                      {t.expenses.distributeEqually}
                    </button>
                  </div>
                  {members.map((member) => (
                    <div key={member.id} className="flex items-center gap-3">
                      <span className="text-sm text-gray-700 w-20">{member.name}</span>
                      <div className="flex-1 relative">
                        <input
                          type="number"
                          step="0.01"
                          value={splits[member.id] || 0}
                          onChange={(e) => handleSplitChange(member.id, e.target.value)}
                          className="w-full px-3 py-2 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                          min="0"
                          max="100"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">
                          %
                        </span>
                      </div>
                    </div>
                  ))}
                  <div className="text-sm text-gray-600">
                    Total:{' '}
                    <span
                      className={`font-medium ${
                        Math.abs(Object.values(splits).reduce((sum, val) => sum + val, 0) - 100) <
                        0.01
                          ? 'text-green-600'
                          : 'text-red-600'
                      }`}
                    >
                      {Object.values(splits)
                        .reduce((sum, val) => sum + val, 0)
                        .toFixed(2)}
                      %
                    </span>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
            >
              {t.common.cancel}
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
            >
              {t.expenses.addExpense}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}