import { ArrowRight } from 'lucide-react';
import { Settlement, Member } from '../types/finance';
import { useLanguage } from '../hooks/useLanguage';

interface SettlementsCardProps {
  settlements: Settlement[];
  members: Member[];
}

export function SettlementsCard({ settlements, members }: SettlementsCardProps) {
  const { t } = useLanguage();
  
  const getMemberName = (memberId: string) => {
    return members.find((m) => m.id === memberId)?.name || 'Unknown';
  };

  if (settlements.length === 0) {
    return (
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">{t.settlements.title}</h3>
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <span className="text-3xl">🎉</span>
          </div>
          <p className="font-semibold text-gray-900 mb-1">{t.settlements.emptyState}</p>
          <p className="text-sm text-gray-500">{t.settlements.emptyStateDescription}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <h3 className="font-semibold text-gray-900 mb-4">{t.settlements.whoOwesWhom}</h3>
      <div className="space-y-3">
        {settlements.map((settlement, index) => (
          <div
            key={index}
            className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg"
          >
            <div className="flex items-center gap-3 flex-1">
              <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-sm">
                  {getMemberName(settlement.from).charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <p className="font-medium text-gray-900">{getMemberName(settlement.from)}</p>
                <p className="text-sm text-gray-500">{t.settlements.owes}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <ArrowRight className="w-5 h-5 text-gray-400" />
              <div className="text-right">
                <p className="font-bold text-purple-600 text-lg">
                  ${settlement.amount.toFixed(2)}
                </p>
              </div>
              <ArrowRight className="w-5 h-5 text-gray-400" />
            </div>

            <div className="flex items-center gap-3 flex-1 justify-end">
              <div className="text-right">
                <p className="font-medium text-gray-900">{getMemberName(settlement.to)}</p>
                <p className="text-sm text-gray-500">{t.settlements.pays}</p>
              </div>
              <div className="w-10 h-10 bg-pink-600 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold text-sm">
                  {getMemberName(settlement.to).charAt(0).toUpperCase()}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}