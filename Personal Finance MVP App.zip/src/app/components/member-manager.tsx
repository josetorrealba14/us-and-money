import { useState } from 'react';
import { User, Plus, X, Edit2, Check } from 'lucide-react';
import { Member, Mode } from '../types/finance';
import { useLanguage } from '../hooks/useLanguage';

interface MemberManagerProps {
  members: Member[];
  mode: Mode;
  onUpdateMember: (id: string, name: string) => void;
  onAddMember: (name: string) => void;
  onRemoveMember: (id: string) => void;
}

export function MemberManager({
  members,
  mode,
  onUpdateMember,
  onAddMember,
  onRemoveMember,
}: MemberManagerProps) {
  const { t } = useLanguage();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [newMemberName, setNewMemberName] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const canAddMembers = mode === 'roommates' && members.length < 6;
  const canRemoveMembers = mode === 'roommates' && members.length > 3;

  const handleStartEdit = (member: Member) => {
    setEditingId(member.id);
    setEditName(member.name);
  };

  const handleSaveEdit = (memberId: string) => {
    if (editName.trim()) {
      onUpdateMember(memberId, editName.trim());
    }
    setEditingId(null);
    setEditName('');
  };

  const handleAddMember = () => {
    if (newMemberName.trim()) {
      onAddMember(newMemberName.trim());
      setNewMemberName('');
      setShowAddForm(false);
    }
  };

  if (mode === 'solo') {
    return null;
  }

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <h3 className="font-semibold text-gray-900 mb-4">{t.members.members}</h3>
      <div className="space-y-3">
        {members.map((member) => (
          <div
            key={member.id}
            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center gap-3 flex-1">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-purple-600" />
              </div>
              {editingId === member.id ? (
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveEdit(member.id);
                    if (e.key === 'Escape') setEditingId(null);
                  }}
                />
              ) : (
                <span className="font-medium text-gray-900">{member.name}</span>
              )}
            </div>
            <div className="flex items-center gap-2">
              {editingId === member.id ? (
                <>
                  <button
                    onClick={() => handleSaveEdit(member.id)}
                    className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setEditingId(null)}
                    className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => handleStartEdit(member)}
                    className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  {canRemoveMembers && (
                    <button
                      onClick={() => onRemoveMember(member.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ))}

        {/* Add Member Form */}
        {showAddForm ? (
          <div className="flex items-center gap-2 p-3 bg-purple-50 rounded-lg border-2 border-purple-200">
            <input
              type="text"
              value={newMemberName}
              onChange={(e) => setNewMemberName(e.target.value)}
              placeholder={t.members.memberName}
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddMember();
                if (e.key === 'Escape') {
                  setShowAddForm(false);
                  setNewMemberName('');
                }
              }}
            />
            <button
              onClick={handleAddMember}
              className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
            >
              <Check className="w-5 h-5" />
            </button>
            <button
              onClick={() => {
                setShowAddForm(false);
                setNewMemberName('');
              }}
              className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        ) : (
          canAddMembers && (
            <button
              onClick={() => setShowAddForm(true)}
              className="w-full flex items-center justify-center gap-2 p-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-purple-600 hover:text-purple-600 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span className="text-sm font-medium">{t.members.addMember}</span>
            </button>
          )
        )}
      </div>
    </div>
  );
}