import { useState } from 'react';
import { Users, DollarSign, TrendingUp, X } from 'lucide-react';
import { Mode } from '../types/finance';
import { useLanguage } from '../hooks/useLanguage';

interface OnboardingProps {
  isOpen: boolean;
  onComplete: (mode: Mode) => void;
  onSkip: () => void;
}

export function Onboarding({ isOpen, onComplete, onSkip }: OnboardingProps) {
  const { t, lang } = useLanguage();
  const [step, setStep] = useState(1);
  const [selectedMode, setSelectedMode] = useState<Mode>('solo');

  if (!isOpen) return null;

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      onComplete(selectedMode);
    }
  };

  const handleSkip = () => {
    onSkip();
  };

  // Get translated "You" name
  const youName = t.common.you;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full overflow-hidden">
        {/* Header */}
        <div className="relative bg-gradient-to-br from-purple-600 to-pink-600 p-8 text-white">
          <button
            onClick={handleSkip}
            className="absolute top-4 right-4 p-2 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="text-center">
            <div className="text-sm font-medium mb-2 text-white/80">
              {t.onboarding.stepLabel} {step} {t.onboarding.ofLabel} 3
            </div>
            <div className="w-full bg-white/20 rounded-full h-2 mb-6">
              <div
                className="bg-white rounded-full h-2 transition-all duration-300"
                style={{ width: `${(step / 3) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-8">
          {step === 1 && (
            <div className="text-center">
              <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-10 h-10 text-purple-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">
                {t.onboarding.step1.title}
              </h2>
              <p className="text-gray-600 mb-8">
                {t.onboarding.step1.description}
              </p>

              <div className="space-y-3">
                <button
                  onClick={() => setSelectedMode('solo')}
                  className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                    selectedMode === 'solo'
                      ? 'border-purple-600 bg-purple-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-semibold text-gray-900 mb-1">{t.modes.solo}</div>
                  <div className="text-sm text-gray-600">
                    {t.onboarding.step1.soloDescription}
                  </div>
                </button>

                <button
                  onClick={() => setSelectedMode('couple')}
                  className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                    selectedMode === 'couple'
                      ? 'border-purple-600 bg-purple-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-semibold text-gray-900 mb-1">{t.modes.couple}</div>
                  <div className="text-sm text-gray-600">
                    {t.onboarding.step1.coupleDescription}
                  </div>
                </button>

                <button
                  onClick={() => setSelectedMode('roommates')}
                  className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                    selectedMode === 'roommates'
                      ? 'border-purple-600 bg-purple-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="font-semibold text-gray-900 mb-1">{t.modes.roommates}</div>
                  <div className="text-sm text-gray-600">
                    {t.onboarding.step1.roommatesDescription}
                  </div>
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="text-center">
              <div className="w-20 h-20 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <DollarSign className="w-10 h-10 text-pink-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">
                {t.onboarding.step2.title}
              </h2>
              <p className="text-gray-600 mb-6">
                {t.onboarding.step2.description}
              </p>
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 text-left">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <span className="text-white font-bold">$</span>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 mb-1">
                      {t.onboarding.step2.exampleTitle}
                    </div>
                    <div className="text-sm text-gray-600 mb-2">
                      {t.onboarding.step2.examplePaidBy} {youName} • {t.onboarding.step2.exampleSplitEqually}
                    </div>
                    <div className="text-lg font-bold text-purple-600">$145.50</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-3">
                {t.onboarding.step3.title}
              </h2>
              <p className="text-gray-600 mb-6">
                {selectedMode === 'solo'
                  ? t.onboarding.step3.descriptionSolo
                  : t.onboarding.step3.descriptionShared}
              </p>
              {selectedMode !== 'solo' && (
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold text-sm">J</span>
                      </div>
                      <span className="font-medium text-gray-900">Jordan</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600">{t.onboarding.step3.exampleOwes}</div>
                      <div className="font-bold text-purple-600">$42.00</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-medium text-gray-900">Alex</span>
                      <div className="w-10 h-10 bg-pink-600 rounded-full flex items-center justify-center">
                        <span className="text-white font-semibold text-sm">A</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {selectedMode === 'solo' && (
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6">
                  <div className="text-4xl font-bold text-purple-600 mb-2">$1,240</div>
                  <div className="text-sm text-gray-600">{t.onboarding.step3.exampleMonthlyExpenses}</div>
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3 mt-8">
            {step > 1 && (
              <button
                onClick={() => setStep(step - 1)}
                className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
              >
                {t.onboarding.back}
              </button>
            )}
            <button
              onClick={handleNext}
              className={`px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all ${
                step === 1 ? 'flex-1' : 'flex-1'
              }`}
            >
              {step === 3 ? t.onboarding.finish : t.onboarding.next}
            </button>
          </div>

          <button
            onClick={handleSkip}
            className="w-full mt-4 text-sm text-gray-500 hover:text-gray-700 transition-colors"
          >
            {t.onboarding.skip}
          </button>
        </div>
      </div>
    </div>
  );
}