import { User, Users, Home } from 'lucide-react';
import { Mode } from '../data/mock-data';
import { useLanguage } from '../hooks/useLanguage';

interface ModeSelectorProps {
  mode: Mode;
  onModeChange: (mode: Mode) => void;
}

export function ModeSelector({ mode, onModeChange }: ModeSelectorProps) {
  const { t } = useLanguage();
  
  const modes: { value: Mode; label: string; icon: React.ReactNode }[] = [
    { value: 'solo', label: t.modes.solo, icon: <User className="w-4 h-4" /> },
    { value: 'couple', label: t.modes.couple, icon: <Users className="w-4 h-4" /> },
    { value: 'roommates', label: t.modes.roommates, icon: <Home className="w-4 h-4" /> },
  ];

  return (
    <div className="flex gap-2 p-1 bg-gray-100 rounded-lg">
      {modes.map((m) => (
        <button
          key={m.value}
          onClick={() => onModeChange(m.value)}
          className={`flex items-center gap-2 px-4 py-2 rounded-md transition-all text-sm font-medium ${
            mode === m.value
              ? 'bg-white text-purple-600 shadow-sm'
              : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          {m.icon}
          <span className="hidden sm:inline">{m.label}</span>
        </button>
      ))}
    </div>
  );
}