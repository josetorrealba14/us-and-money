import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Mode } from '../types/finance';
import { useLanguage } from '../hooks/useLanguage';

interface SplitChartProps {
  data: { name: string; value: number }[];
  mode: Mode;
}

export function SplitChart({ data, mode }: SplitChartProps) {
  const { t } = useLanguage();
  const title = mode === 'solo' ? t.dashboard.yourExpenses : t.dashboard.expenseSplit;

  const renderCustomLabel = (entry: any) => {
    if (mode === 'solo') return '';
    return `${entry.name}`;
  };

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <h3 className="font-semibold text-gray-900 mb-4">{title}</h3>
      {mode === 'solo' ? (
        <div className="flex items-center justify-center h-[250px]">
          <div className="text-center">
            <div className="w-32 h-32 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
              <span className="text-4xl font-bold text-purple-600">100%</span>
            </div>
            <p className="text-gray-600">All expenses are yours</p>
          </div>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={renderCustomLabel}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                fontSize: '14px',
              }}
              formatter={(value: number) => `$${value.toFixed(0)}`}
            />
            <Legend wrapperStyle={{ fontSize: '14px' }} />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}