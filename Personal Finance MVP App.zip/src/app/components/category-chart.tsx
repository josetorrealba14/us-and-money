import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { useLanguage } from '../hooks/useLanguage';

interface CategoryChartProps {
  data: { name: string; value: number; color: string }[];
}

export function CategoryChart({ data }: CategoryChartProps) {
  const { t } = useLanguage();

  // Find the top category
  const topCategory = data.length > 0 ? data[0].name : null;
  const topCategoryAmount = data.length > 0 ? data[0].value : 0;

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <h3 className="font-semibold text-gray-900 mb-4">{t.dashboard.spendingByCategory}</h3>
      {data.length === 0 ? (
        <div className="flex items-center justify-center h-[250px]">
          <div className="text-center">
            <div className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl text-gray-400">📊</span>
            </div>
            <p className="text-gray-600">{t.dashboard.noSpendingYet}</p>
          </div>
        </div>
      ) : (
        <>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => entry.name}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: '#fff',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  fontSize: '14px',
                }}
                formatter={(value: number) => `$${value.toFixed(2)}`}
              />
              <Legend wrapperStyle={{ fontSize: '14px' }} />
            </PieChart>
          </ResponsiveContainer>
          
          {/* Top category insight */}
          {topCategory && (
            <div className="mt-4 pt-4 border-t border-gray-100">
              <p className="text-sm text-gray-600">
                <span className="font-medium">{t.dashboard.topCategory}:</span>{' '}
                <span className="text-purple-600 font-semibold">{topCategory}</span> (${topCategoryAmount.toFixed(2)})
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
