'use client';

import { useState } from 'react';
import { Target, Edit2, Check, X, Settings } from 'lucide-react';
import { Mode } from '../types/finance';
import { StatusIndicator } from './status-indicator';
import { useLanguage } from '../hooks/useLanguage';

interface BudgetCardProps {
  budget?: number;
  totalExpenses: number;
  mode: Mode;
  budgetStatus: 'on-track' | 'watch' | 'over' | null;
  includePersonalInBudget: boolean;
  onSetBudget: (budget: number | undefined) => void;
  onToggleIncludePersonal?: (include: boolean) => void;
}

const BUDGET_PRESETS = [500, 1000, 1500, 2000, 3000];

export function BudgetCard({ 
  budget, 
  totalExpenses, 
  mode, 
  budgetStatus,
  includePersonalInBudget,
  onSetBudget,
  onToggleIncludePersonal,
}: BudgetCardProps) {
  const { t } = useLanguage();
  const [isEditing, setIsEditing] = useState(false);
  const [budgetInput, setBudgetInput] = useState(budget?.toString() || '');
  const [useCustom, setUseCustom] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const handlePresetSelect = (amount: number) => {
    onSetBudget(amount);
    setIsEditing(false);
    setUseCustom(false);
  };

  const handleCustom = () => {
    setUseCustom(true);
    setBudgetInput('');
  };

  const handleSave = () => {
    const value = parseFloat(budgetInput);
    if (!isNaN(value) && value > 0) {
      onSetBudget(value);
      setIsEditing(false);
      setUseCustom(false);
    } else if (budgetInput === '') {
      onSetBudget(undefined);
      setIsEditing(false);
      setUseCustom(false);
    }
  };

  const handleCancel = () => {
    setBudgetInput(budget?.toString() || '');
    setIsEditing(false);
    setUseCustom(false);
  };

  const getBudgetLabel = () => {
    if (mode === 'solo') return t.budget.personalBudget;
    if (mode === 'couple') return t.budget.sharedBudgetCouple;
    return t.budget.sharedBudgetRoommates;
  };

  const getBudgetDescription = () => {
    if (mode === 'solo') return t.budget.setPersonalDescription;
    if (mode === 'couple') return t.budget.setCoupleDescription;
    return t.budget.setRoommatesDescription;
  };

  const getBudgetHelperText = () => {
    if (mode === 'solo') return t.budget.helperPersonal;
    if (includePersonalInBudget) {
      return t.budget.helperSharedAll;
    }
    return t.budget.helperSharedOnly;
  };

  if (!budget && !isEditing) {
    return (
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-6 border-2 border-dashed border-blue-200">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-2">{getBudgetLabel()}</h3>
            <p className="text-sm text-gray-600 mb-4">
              {getBudgetDescription()}
            </p>
            <button
              onClick={() => setIsEditing(true)}
              className="px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-medium hover:shadow-lg transition-all text-sm"
            >
              {t.budget.setBudget}
            </button>
          </div>
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
            <Target className="w-6 h-6 text-blue-600" />
          </div>
        </div>
      </div>
    );
  }

  const percentage = budget ? Math.min((totalExpenses / budget) * 100, 100) : 0;
  const remaining = budget ? budget - totalExpenses : 0;
  const isOver = budget ? totalExpenses > budget : false;

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
            isOver ? 'bg-red-100' : 'bg-blue-100'
          }`}>
            <Target className={`w-5 h-5 ${isOver ? 'text-red-600' : 'text-blue-600'}`} />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{getBudgetLabel()}</h3>
            {!isEditing && budget && (
              <div>
                <p className="text-sm text-gray-500">
                  ${budget.toLocaleString()} / month
                </p>
                <p className="text-xs text-gray-400 mt-0.5">
                  {getBudgetHelperText()}
                </p>
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {!isEditing && mode !== 'solo' && onToggleIncludePersonal && (
            <div className="relative">
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                title="Budget settings"
              >
                <Settings className="w-4 h-4" />
              </button>
              
              {/* Settings Dropdown */}
              {showSettings && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setShowSettings(false)}
                  />
                  <div className="absolute right-0 top-12 z-20 bg-white rounded-xl shadow-lg border border-gray-200 p-4 w-72">
                    <h4 className="font-semibold text-gray-900 mb-3 text-sm">{t.budget.budgetSettings}</h4>
                    <div className="space-y-3">
                      <div className="flex items-start gap-3">
                        <button
                          onClick={() => {
                            onToggleIncludePersonal(!includePersonalInBudget);
                            setShowSettings(false);
                          }}
                          className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2 ${
                            includePersonalInBudget ? 'bg-purple-600' : 'bg-gray-200'
                          }`}
                        >
                          <span
                            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                              includePersonalInBudget ? 'translate-x-5' : 'translate-x-0'
                            }`}
                          />
                        </button>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900">
                            {t.budget.includePersonalExpenses}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {includePersonalInBudget 
                              ? t.budget.includePersonalOn
                              : t.budget.includePersonalOff
                            }
                          </p>
                          <p className="text-xs text-gray-400 mt-2 italic">
                            {t.budget.settlementsNote}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
          {!isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Edit2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {isEditing ? (
        <div className="space-y-4">
          {!useCustom ? (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Choose a budget amount:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {BUDGET_PRESETS.map((amount) => (
                    <button
                      key={amount}
                      onClick={() => handlePresetSelect(amount)}
                      className="px-4 py-3 border-2 border-gray-300 hover:border-purple-600 hover:bg-purple-50 rounded-lg font-semibold text-gray-900 transition-all"
                    >
                      ${amount}
                    </button>
                  ))}
                  <button
                    onClick={handleCustom}
                    className="px-4 py-3 border-2 border-purple-600 bg-purple-50 text-purple-600 rounded-lg font-semibold transition-all"
                  >
                    Custom
                  </button>
                </div>
              </div>
              <button
                onClick={handleCancel}
                className="w-full px-4 py-2 border-2 border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </>
          ) : (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Enter custom amount:
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                  <input
                    type="number"
                    step="0.01"
                    value={budgetInput}
                    onChange={(e) => setBudgetInput(e.target.value)}
                    className="w-full pl-8 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                    placeholder="Enter amount"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSave();
                      if (e.key === 'Escape') handleCancel();
                    }}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleSave}
                  className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Save
                </button>
                <button
                  onClick={() => setUseCustom(false)}
                  className="px-4 py-2 border-2 border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </>
          )}
        </div>
      ) : (
        <>
          <div className="space-y-3 mb-4">
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-gray-900">
                ${totalExpenses.toLocaleString()}
              </span>
              <div className="flex items-center gap-3">
                <span className={`text-sm font-medium ${
                  isOver ? 'text-red-600' : 'text-gray-600'
                }`}>
                  {percentage.toFixed(0)}%
                </span>
                {budgetStatus && <StatusIndicator status={budgetStatus} />}
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
              <div
                className={`h-3 rounded-full transition-all duration-500 ${
                  isOver
                    ? 'bg-gradient-to-r from-red-500 to-red-600'
                    : 'bg-gradient-to-r from-purple-600 to-pink-600'
                }`}
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>

          {isOver ? (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm font-medium text-red-800">
                Over budget by ${Math.abs(remaining).toLocaleString()}
              </p>
              <p className="text-xs text-red-600 mt-1">
                Consider reviewing your spending to get back on track
              </p>
            </div>
          ) : (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm font-medium text-green-800">
                ${remaining.toLocaleString()} remaining
              </p>
              <p className="text-xs text-green-600 mt-1">
                You're doing great! Keep it up
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}