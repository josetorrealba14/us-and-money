import { CheckCircle, AlertCircle, XCircle } from 'lucide-react';

interface StatusIndicatorProps {
  status: 'on-track' | 'watch' | 'over';
}

export function StatusIndicator({ status }: StatusIndicatorProps) {
  const getConfig = () => {
    switch (status) {
      case 'on-track':
        return {
          icon: CheckCircle,
          label: 'On track',
          bg: 'bg-green-50',
          border: 'border-green-200',
          text: 'text-green-700',
          iconColor: 'text-green-600',
        };
      case 'watch':
        return {
          icon: AlertCircle,
          label: 'Watch spending',
          bg: 'bg-yellow-50',
          border: 'border-yellow-200',
          text: 'text-yellow-700',
          iconColor: 'text-yellow-600',
        };
      case 'over':
        return {
          icon: XCircle,
          label: 'Over budget',
          bg: 'bg-red-50',
          border: 'border-red-200',
          text: 'text-red-700',
          iconColor: 'text-red-600',
        };
    }
  };

  const config = getConfig();
  const Icon = config.icon;

  return (
    <div
      className={`inline-flex items-center gap-2 px-3 py-2 rounded-lg border ${config.bg} ${config.border}`}
    >
      <Icon className={`w-4 h-4 ${config.iconColor}`} />
      <span className={`text-sm font-medium ${config.text}`}>{config.label}</span>
    </div>
  );
}
