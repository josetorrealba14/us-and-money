'use client';

import { useState } from 'react';
import { useLanguage } from '../hooks/useLanguage';
import { Mode, Member } from '../types/finance';
import { X, Users, Heart, Home } from 'lucide-react';

interface ModeSetupProps {
  mode: Mode;
  onComplete: (members: Member[]) => void;
  onClose?: () => void;
}

export function ModeSetup({ mode, onComplete, onClose }: ModeSetupProps) {
  const { t, lang } = useLanguage();
  const [step, setStep] = useState(1);
  const [partnerName, setPartnerName] = useState('');
  const [roommateCount, setRoommateCount] = useState(2);
  const [roommateNames, setRoommateNames] = useState<string[]>(['', '']);

  const youName = lang === 'es' ? 'Tú' : 'You';

  const handleCoupleComplete = () => {
    if (!partnerName.trim()) return;
    
    const members: Member[] = [
      { id: 'user1', name: youName },
      { id: 'user2', name: partnerName.trim() },
    ];
    onComplete(members);
  };

  const handleRoommatesComplete = () => {
    const validNames = roommateNames.filter((name) => name.trim());
    if (validNames.length === 0) return;

    const members: Member[] = [
      { id: 'user1', name: youName },
      ...validNames.map((name, index) => ({
        id: `user${index + 2}`,
        name: name.trim(),
      })),
    ];
    onComplete(members);
  };

  const updateRoommateCount = (count: number) => {
    setRoommateCount(count);
    setRoommateNames(Array(count).fill('').map((_, i) => roommateNames[i] || ''));
  };

  const updateRoommateName = (index: number, name: string) => {
    const newNames = [...roommateNames];
    newNames[index] = name;
    setRoommateNames(newNames);
  };

  if (mode === 'solo') {
    // Solo mode doesn't need setup - auto-complete
    const members: Member[] = [{ id: 'user1', name: youName }];
    onComplete(members);
    return null;
  }

  if (mode === 'couple') {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 relative">
          {onClose && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center mb-4">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{t.modeSetup.couple.title}</h2>
            <p className="text-sm text-gray-600 text-center">{t.modeSetup.couple.description}</p>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                {t.modeSetup.couple.questionPartnerName}
              </label>
              <input
                type="text"
                value={partnerName}
                onChange={(e) => setPartnerName(e.target.value)}
                placeholder={t.modeSetup.couple.partnerNamePlaceholder}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                autoFocus
              />
            </div>

            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
              <p className="text-sm text-purple-900">{t.modeSetup.couple.helperText}</p>
            </div>

            <button
              onClick={handleCoupleComplete}
              disabled={!partnerName.trim()}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-medium hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {t.modeSetup.completeSetup}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'roommates') {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 relative">
          {onClose && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          <div className="flex flex-col items-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-full flex items-center justify-center mb-4">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{t.modeSetup.roommates.title}</h2>
            <p className="text-sm text-gray-600 text-center">{t.modeSetup.roommates.description}</p>
          </div>

          <div className="space-y-6">
            {step === 1 && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    {t.modeSetup.roommates.questionCount}
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((count) => (
                      <button
                        key={count}
                        onClick={() => updateRoommateCount(count)}
                        className={`py-3 rounded-lg font-medium transition-all ${
                          roommateCount === count
                            ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {count}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    {t.modeSetup.roommates.totalPeople}: {roommateCount + 1}
                  </p>
                </div>

                <button
                  onClick={() => setStep(2)}
                  className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg font-medium hover:from-blue-700 hover:to-cyan-700 transition-all"
                >
                  {t.common.continue}
                </button>
              </>
            )}

            {step === 2 && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    {t.modeSetup.roommates.nameRoommates}
                  </label>
                  <div className="space-y-3">
                    {roommateNames.map((name, index) => (
                      <input
                        key={index}
                        type="text"
                        value={name}
                        onChange={(e) => updateRoommateName(index, e.target.value)}
                        placeholder={`${t.modeSetup.roommates.roommatePlaceholder} ${index + 1}`}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        autoFocus={index === 0}
                      />
                    ))}
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-900">{t.modeSetup.roommates.helperText}</p>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setStep(1)}
                    className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-all"
                  >
                    {t.common.back}
                  </button>
                  <button
                    onClick={handleRoommatesComplete}
                    disabled={roommateNames.filter((n) => n.trim()).length === 0}
                    className="flex-1 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg font-medium hover:from-blue-700 hover:to-cyan-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {t.modeSetup.completeSetup}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  return null;
}
