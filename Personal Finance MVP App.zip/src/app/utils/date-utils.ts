export function getMonthKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

export function getCurrentMonthKey(): string {
  return getMonthKey(new Date());
}

export function parseMonthKey(key: string): Date {
  const [year, month] = key.split('-').map(Number);
  return new Date(year, month - 1, 1);
}

export function getMonthLabel(key: string): string {
  const date = parseMonthKey(key);
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

export function getPreviousMonthKey(key: string): string {
  const date = parseMonthKey(key);
  date.setMonth(date.getMonth() - 1);
  return getMonthKey(date);
}

export function getNextMonthKey(key: string): string {
  const date = parseMonthKey(key);
  date.setMonth(date.getMonth() + 1);
  return getMonthKey(date);
}

export function isCurrentMonth(key: string): boolean {
  return key === getCurrentMonthKey();
}
