# Us&Money - Personal Finance MVP

A modern, mobile-first personal finance management app focused on budget tracking and shared expenses.

## Features

### 🎯 Three Isolated Usage Modes with Guided Setup
- **Solo Mode**: Auto-creates "You" member, tracks your personal budget
- **Couple Mode**: 
  - Setup asks: "What is your partner's name?"
  - Creates "You" + partner
  - Shared budget for both of you
- **Roommates Mode**: 
  - Setup asks: "How many roommates do you have?"
  - Names each person
  - Shared budget for the household
- **Each mode has its own isolated workspace** - expenses, members, budgets, and monthly history are completely separate

### 💰 Budget-Centric Financial Tracking
- **Monthly Budget** is the core metric that drives all insights
- **Quick Budget Presets**: $500 / $1000 / $1500 / $2000 / $3000 / Custom
- Set a personal budget (Solo) or shared group budget (Couple/Roommates)
- Real-time tracking of spending against budget
- Visual progress bar showing budget usage
- **Smart Status Indicator**:
  - 🟢 **"On track"**: Spending pace matches time progress
  - 🟡 **"Watch spending"**: Spending 10%+ ahead of schedule
  - 🔴 **"Over budget"**: Exceeded budget amount
- Color-coded states throughout the UI
- **Budget-derived metrics**:
  - Total Spent vs Budget (%)
  - Remaining Budget
  - Projected Savings (if under budget)
  - Daily average and projected total (if no budget set)

### ⚙️ Budget Settings (Couple/Roommates)
- **"Include personal expenses in budget"** toggle
  - **ON** (default): Counts shared + personal expenses toward budget
  - **OFF**: Counts only shared expenses toward budget
  - Accessible via settings icon in budget card
  - Settlements always use only shared expenses
  - Persists per workspace

### 📊 Smart Expense Management
- Add expenses with detailed information:
  - Amount, description, date
  - Who paid
  - Shared or personal expense
  - Split type (equal or custom percentage)
  - Optional category (Food, Rent, Transport, Fun, Utilities, Other)
- Delete expenses with confirmation
- View transaction history
- Filter by category
- Clear mode-specific copy:
  - Solo: "Your personal budget" + "Tracks all your personal expenses"
  - Couple: "Shared budget for both of you" + context about shared/personal
  - Roommates: "Shared budget for the household" + context about shared/personal

### 🗓️ Month-by-Month Tracking
- Navigate between past, current, and future months
- Each month has its own budget and expenses
- Historical data preserved per mode

### 📈 Dashboard Features
- **Financial Overview** (budget-based):
  - Total spent vs budget with status indicator
  - Remaining budget or over-budget amount
  - Projected savings
- **Visual Charts**:
  - Budget vs Actual Spending (weekly breakdown)
  - Expense split by person (pie chart)
- **Settlement Calculations** (Couple/Roommates only):
  - Automatic "who owes whom" calculations
  - Minimized number of transactions needed
  - Split logic used for debt settlement only, not budgeting
  - Always based on shared expenses only
- **Member Management** (Couple/Roommates):
  - Edit member names
  - Add/remove members (roommates mode)

### ✨ User Experience Polish
- **Mode-Specific Onboarding**: 3-step tutorial on first visit
- **Guided Setup Per Mode**: Human, intuitive setup flow
- **Toast Notifications**: Feedback for all actions
- **Category Filtering**: Quick filters for expense categories
- **Enhanced Empty States**: Friendly messages and clear CTAs
- **Confirmation Dialogs**: Before destructive actions
- **Status Indicators**: Glanceable budget health
- **Clear Helper Text**: Non-jargon, mode-specific copy

### 💾 Data Architecture
- **Isolated Workspaces**: Each mode (solo/couple/roommates) has completely separate data
- **Per-Month Storage**: Expenses and budgets stored by month
- **localStorage Persistence**: All data saved automatically
- **No Cross-Mode Contamination**: Switching modes doesn't affect other workspaces
- **Per-Workspace Settings**: Setup completion, budget settings persist per mode

## How It Works

### Budget Model
1. **Solo Mode**: Set your personal monthly budget (tracks all your expenses)
2. **Couple/Roommates Mode**: 
   - Set a shared group budget (not per-person)
   - Choose whether to include personal expenses in budget tracking
   - All spending is tracked against this budget
3. KPIs show: spent vs budget, remaining, and projected savings
4. Smart status indicator shows if you're on track, need to watch spending, or over budget

### Expense Splitting (Couple/Roommates)
- **Equal Split**: Divides expense equally among all members
- **Percentage Split**: Custom percentages for each member (must total 100%)
- **Personal Expenses**: Not shared, only affects the payer
- **Split logic is only used for debt settlement**, not for budget calculations
- Budget can include or exclude personal expenses (user's choice)

### Balance Calculations
The app calculates balances by:
1. Tracking who paid for each expense
2. Calculating each person's share based on split type
3. Computing net balances (positive = owed money, negative = owes money)
4. Only shared expenses count toward settlements

### Settlement Algorithm
Uses a greedy algorithm to minimize the number of transactions:
1. Separate members into creditors (owed money) and debtors (owe money)
2. Match largest creditor with largest debtor
3. Settle as much as possible with one transaction
4. Repeat until all balanced

## Tech Stack
- React 18
- React Router 7
- Tailwind CSS v4
- Recharts (charts)
- Lucide React (icons)
- Sonner (toast notifications)
- TypeScript
- localStorage for persistence

## Data Model

```typescript
AppState:
  - currentMode: 'solo' | 'couple' | 'roommates'
  - workspaces:
      - solo: { 
          members[], 
          months: { "2026-02": { expenses[], budget } },
          setupComplete: true,
          includePersonalInBudget: true
        }
      - couple: { 
          members[], 
          months: { "2026-02": { expenses[], budget } },
          setupComplete: boolean,
          includePersonalInBudget: boolean
        }
      - roommates: { 
          members[], 
          months: { "2026-02": { expenses[], budget } },
          setupComplete: boolean,
          includePersonalInBudget: boolean
        }
  - hasSeenOnboarding: boolean
```

## Target Audience
People aged 18-35 who want to:
- Track spending against a monthly budget with clear status indicators
- Split expenses fairly with partners or roommates
- Manage money in 2 minutes a day
- Stay on top of their finances without complexity or financial jargon
- Get instant feedback on their spending pace